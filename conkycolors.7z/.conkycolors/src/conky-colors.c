/*
# Copyright (C) 2009 Helmuth Saatkamp (helmuthdu)
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
*/

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

int i, True=1, False=0;

int cpu=2, cputemp=0, proc=0, swap=0, logo=0, set_process=0, m=0, aptget=0, dark=0, alldark=0, alllight=0, gmail=0, nvidia=0, hdtype=0, hdtemp1=0, hdtemp2=0, hdtemp3=0, hdtemp4=0, nodata=0, clocktype=0, set_calendar=0, bbcweather=0, bbccode=3849, set_weather=0, weatherplus=0, unit=0, set_battery=0, set_network=0, set_hd=0, mpd=0, set_photo=0, rhythmbox=0, banshee=0, exaile=0, cover=0, pidgin=0, limit=5, todo=0, shiki=0, shikidust=0, dust=0, custom=0, eth=0, wlan=0, ppp=0, go2=32, yp=0, yc=0;
char theme[31], defaultcolor[31], color0[31], color1[31], color2[31], color3[31], language[31], side[31], weather_code[31], imperial[31], logo_letter[31], user[31], password[31], dev1[31], dev2[31], dev3[31], dev4[31];
char sys[31], processes[31], battery[31], uptime[31], packages[31], date[31], photo[31], hd[31], temperature[31], network[31], total[31], up[31], down[31], upload[31], download[31], signal[31], localip[31], publicip[31], nonet[31], Weather[31], noweather[31], station[31], rain[31], humidity[31], sunrise[31], sunset[31], moon[31], updates[31], new[31], status[31], song[31], time[31], nopidgin[31], norhythmbox[31];

void help() {
	printf("\t./conky-colors <options>\n\n");
	printf("\toptions:\n");
	printf("\t--lang=<language> - Set default language:\n");
	printf("\t\tbulgarian OR bg\n");
	printf("\t\tdeutsch OR de\n");
	printf("\t\tenglish OR en*\n");
	printf("\t\testonian OR et\n");
	printf("\t\titalian OR it\n");
	printf("\t\tpolish OR pl\n");
	printf("\t\tportuguese OR pt\n");
	printf("\t\trussian OR ru\n");
	printf("\t\tspanish OR es\n");
	printf("\t--theme=<theme> - Set default theme color\n");
	printf("\t\tgnome-brave\n");
	printf("\t\tgnome-carbonite\n");
	printf("\t\tgnome-human*\n");
	printf("\t\tgnome-noble\n");
	printf("\t\tgnome-tribute\n");
	printf("\t\tgnome-wine\n");
	printf("\t\tgnome-wise\n");
	printf("\t\tshiki-brave\n");
	printf("\t\tshiki-human\n");
	printf("\t\tshiki-noble\n");
	printf("\t\tshiki-wine\n");
	printf("\t\tshiki-wise\n");
	printf("\t\tshiki-dust\n");
	printf("\t\tdust\n");
	printf("\t\tcustom\n");
	printf("\t\t\tThese options work only with --theme=custom option\n");
	printf("\t\t\t--default-color=<value>\n");
	printf("\t\t\t--color0=<value>\n");
	printf("\t\t\t--color1=<value>\n");
	printf("\t\t\t--color2=<value>\n");
	printf("\t--dark - Set Dark Brightness(Don't work with skiki-colors/shikidust/dust/custom themes)'\n");
	printf("\t--alldark - Set Dark Brightness for all(Don't work with any theme)'\n");
	printf("\t--alllight - Set light Brightness for all(Don't work with any theme)'\n");
	printf("\t--cpu=<number> - Set number of cpu cores\n");
	printf("\t--cputemp - Enable CPU temperature\n");
	printf("\t--swap - Enable SWAP\n");
	printf("\t--battery - Enable battery\n");
	printf("\t--updates - Show updates of Debian/Ubuntu\n");
	printf("\t--proc=<number> - Enable top processes widget and set the number of processes to show [Max = 10]\n");
	printf("\t--clock=<default|classic|slim|modern|lucky|off> - Enable/disable clock widget and set type\n");
	printf("\t--nodata - disable Data widget\n");
	printf("\t--calendar - Enable calendar\n");
	printf("\t\t-m - Set monday as first day in the week in calendar\n");
	printf("\t--nvidia - Enable nvidia gpu widget\n");
	printf("\t--todo - Enable ToDo widget\n");
	printf("\t--hd=<default|meerkat|mix|simple> - Enable HD widget\n");
	printf("\t--hdtemp1=<device> - Enable HD temperature [Ex: --hdtemp1=sda]\n");
	printf("\t--hdtemp2=<device> - Enable HD temperature [Ex: --hdtemp2=sdb]\n");
	printf("\t--hdtemp3=<device> - Enable HD temperature [Ex: --hdtemp3=sdc]\n");
	printf("\t--hdtemp4=<device> - Enable HD temperature [Ex: --hdtemp4=sdd]\n");
	printf("\t--photo - Enable Photo widget\n");
	printf("\t--photord - Enable Photo widget in random mode\n");
	printf("\t--mpd - Enable MPD widget\n");
	printf("\t--rhythmbox=<default|cd|case|glassy|vinyl|oldvinyl|simple> - Enable Rhythmbox widget\n");
	printf("\t--banshee=<default|cd|case|glassy|vinyl|oldvinyl|simple> - Enable Banshee widget\n");
	printf("\t--exaile=<default|cd|case|glassy|vinyl|oldvinyl|simple> - Enable Banshee widget\n");
	printf("\t--pidgin - Enable Pidgin widget\n");
	printf("\t\t--limit=<number> - [default: 5] Set a limit to the number of buddies displayed\n");
	printf("\t--gmail - Enable gmail notify\n");
	printf("\t\t--user=<username> - Type your username\n");
	printf("\t\t--passwd=<password> - Type your password\n");
	printf("\t--network - Enable network widget\n");
	printf("\t\t--eth=<number> - Change ethernet device [Default=0]\n");
	printf("\t\t--wlan=<number> - Change wireless device [Default=0]\n");
	printf("\t\t--ppp=<number> - Change 3g modem device [Default=0]\n");
	printf("\t--unit=<C|F>- Force output temperature either in Celius or Fahrenheit\n");
	printf("\t--bbcweather=<AreaID> - Enable weather widget and set your AreaID[Ex: --bbcweather=3849]\n");
	printf("\t--weather=<AreaID> - Enable weather widget and set your AreaID[Ex: --weather=BRXX0043]\n");
	printf("\t--weatherplus - Give a plus to the weather widget\n");
	printf("\t--side=<left|right*> - Set the side of conky in your screem\n");
	printf("\tChoose your Distro Logo:\n");
	printf("\t\t--ubuntu\n\t\t--fedora\n\t\t--opensuse\n\t\t--debian\n\t\t--arch\n\t\t--gentoo\n\t\t--pardus\n\t\t--xfce\n\t\t--gnome\n");
	printf("\t\n(*)default values\n\n");
	exit(0);
}

//Options
void options (int argc, char *argv[]) {

	char *arg;
	char *key, *value;

	strcpy(imperial,"");
	strcpy(user,"<user>");
	strcpy(password,"<password>");
	strcpy(weather_code,"BRXX0043");

	strcpy(defaultcolor, "212526");
	strcpy(color0, "E6E6E6");
	strcpy(color1, "E07A1F");
	strcpy(color2, "E6E6E6");
	strcpy(color3, "CE5C00 E07A1F");

	while (argc--) {

		arg = *argv++;
		key = strsep(&arg, "=");
		value = strsep(&arg, "=");

		if(strcmp("--theme", key) == 0) {
			if(strcmp("gnome-brave", value) == 0 || strcmp("gnome-carbonite", value) == 0 || strcmp("gnome-dust", value) == 0 || strcmp("gnome-human", value) == 0 || strcmp("gnome-illustrious", value) == 0 || strcmp("gnome-noble", value) == 0 || strcmp("gnome-tribute", value) == 0 || strcmp("gnome-wine", value) == 0 || strcmp("gnome-wise", value) == 0)
				strcpy(theme,value);
			else
				if(strcmp("shiki-brave", value) == 0 || strcmp("shiki-human", value) == 0 || strcmp("shiki-illustrious", value) == 0 || strcmp("shiki-noble", value) == 0 || strcmp("shiki-wine", value) == 0 || strcmp("shiki-wise", value) == 0) {
					strcpy(theme,value);
					shiki = True;
					go2 = 38;
				}
			else
				if (strcmp("shiki-dust", value) == 0) {
					strcpy(theme,value);
					shikidust = True;
					go2 = 38;
				}
			else
				if (strcmp("dust", value) == 0) {
					strcpy(theme,value);
					dust = True;
					go2 = 38;
				}
			else
				if (strcmp("custom", value) == 0)
					custom = True;
			else {
				printf("ERRO: THEME unavaliable\n");
				exit(0);
			}
		}
		else
			if(strcmp("--default-color", key) == 0)
				strcpy(defaultcolor, value);
		else
			if(strcmp("--color0", key) == 0)
				strcpy(color0, value);
		else
			if(strcmp("--color1", key) == 0)
				strcpy(color1, value);
		else
			if(strcmp("--color2", key) == 0)
				strcpy(color2, value);
		else
			if(strcmp("--dark", key) == 0)
				dark = True;
		else
			if(strcmp("--alldark", key) == 0)
				alldark = True;
		else
			if(strcmp("--alllight", key) == 0)
				alllight = True;
		else
			if(strcmp("--lang", key) == 0) {
				if(strcmp("portuguese", value) == 0 || strcmp("pt", value) == 0 || strcmp("english", value) == 0 || strcmp("en", value) == 0 || strcmp("deutsch", value) == 0 || strcmp("de", value) == 0 || strcmp("spanish", value) == 0 || strcmp("es", value) == 0 || strcmp("italian", value) == 0 || strcmp("it", value) == 0 || strcmp("polish", value) == 0 || strcmp("pl", value) == 0 || strcmp("it", value) == 0 || strcmp("estonian", value) == 0 || strcmp("et", value) == 0 || strcmp("russian", value) == 0 || strcmp("ru", value) == 0 || strcmp("bulgarian", value) == 0 || strcmp("bg", value) == 0)
					strcpy(language,value);
				else {
					printf("ERRO: LANGUAGE unavaliable\n");
					exit(0);
				}
			}
		else
			if(strcmp("--side", key) == 0)
				strcpy(side,value);
		else
			if(strcmp("--cpu", key) == 0)
				cpu = atoi(value);
		else
			if(strcmp("--cputemp", key) == 0)
				cputemp = True;
		else
			if(strcmp("--updates", key) == 0)
				aptget = True;
		else
			if(strcmp("--swap", key) == 0)
				swap = True;
		else
			if(strcmp("--proc", key) == 0){
					proc = atoi(value);
					set_process = True;
			}
		else
			if(strcmp("--nvidia", key) == 0)
				nvidia = True;
		else
			if(strcmp("--clock", key) == 0) {
				if(strcmp("default", value) == 0);
				else
					if (strcmp("classic", value) == 0)
						clocktype = 1;
				else
					if(strcmp("slim", value) == 0)
						clocktype = 2;
				else
					if(strcmp("modern", value) == 0)
						clocktype = 3;
				else
					if(strcmp("lucky", value) == 0)
						clocktype = 4;
				else
					if(strcmp("off", value) == 0)
						clocktype = 5;
				else {
					printf("ERRO: CLOCK option unavaliable\n");
					exit(0);
				}
			}
		else
			if(strcmp("--nodata", key) == 0)
					nodata = True;
		else
			if(strcmp("--calendar", key) == 0)
					set_calendar = True;
		else
			if(strcmp("-m", key) == 0)
				m = True;
		else
			if(strcmp("--photo", key) == 0)
				set_photo = 1;
		else
			if(strcmp("--photord", key) == 0)
				set_photo = 2;
		else
			if(strcmp("--todo", key) == 0)
				todo = True;
		else
			if(strcmp("--battery", key) == 0)
				set_battery = True;
		else
			if(strcmp("--hd", key) == 0) {
				if(strcmp("default", value) == 0)
					hdtype = 1;
				else
					if(strcmp("meerkat", value) == 0)
						hdtype = 2;
				else
					if(strcmp("mix", value) == 0)
						hdtype = 3;
				else
					if(strcmp("simple", value) == 0)
						hdtype = 4;
				else {
					printf("ERRO: HD option unavaliable\n");
					exit(0);
				}
				set_hd = True;
			}
		else
			if(strcmp("--hdtemp1", key) == 0) {
				strcpy(dev1,value);
				hdtemp1 = True;
			}
		else
			if(strcmp("--hdtemp2", key) == 0) {
				strcpy(dev2,value);
				hdtemp2 = True;
			}
		else
			if(strcmp("--hdtemp3", key) == 0) {
				strcpy(dev3,value);
				hdtemp3 = True;
			}
		else
			if(strcmp("--hdtemp4", key) == 0) {
				strcpy(dev4,value);
				hdtemp4 = True;
			}
		else
			if(strcmp("--mpd", key) == 0)
				mpd = True;
		else
			if(strcmp("--rhythmbox", key) == 0) {
				rhythmbox = True;
				if(strcmp("default", value) == 0)
					cover = 1;
				else
					if(strcmp("simple", value) == 0)
						cover = 2;
				else
					if(strcmp("vinyl", value) == 0)
						cover = 3;
				else
					if(strcmp("cd", value) == 0)
						cover = 4;
				else
					if(strcmp("case", value) == 0)
						cover = 5;
				else
					if(strcmp("glassy", value) == 0)
						cover = 6;
				else
					if(strcmp("oldvinyl", value) == 0)
						cover = 7;
				else {
					printf("ERRO: RHYTHMBOX option unavaliable\n");
					exit(0);
				}
			}
		else
			if(strcmp("--exaile", key) == 0) {
				exaile = True;
				if(strcmp("default", value) == 0)
					cover = 1;
				else
					if(strcmp("simple", value) == 0)
						cover = 2;
				else
					if(strcmp("vinyl", value) == 0)
						cover = 3;
				else
					if(strcmp("cd", value) == 0)
						cover = 4;
				else
					if(strcmp("case", value) == 0)
						cover = 5;
				else
					if(strcmp("glassy", value) == 0)
						cover = 6;
				else
					if(strcmp("oldvinyl", value) == 0)
						cover = 7;
				else {
					printf("ERRO: EXAILE option unavaliable\n");
					exit(0);
				}
			}
		else
			if(strcmp("--banshee", key) == 0) {
				banshee = True;
				if(strcmp("default", value) == 0)
					cover = 1;
				else
					if(strcmp("simple", value) == 0)
						cover = 2;
				else
					if(strcmp("vinyl", value) == 0)
						cover = 3;
				else
					if(strcmp("cd", value) == 0)
						cover = 4;
				else
					if(strcmp("case", value) == 0)
						cover = 5;
				else
					if(strcmp("glassy", value) == 0)
						cover = 6;
				else
					if(strcmp("oldvinyl", value) == 0)
						cover = 7;
				else {
					printf("ERRO: BANSHEE option unavaliable\n");
					exit(0);
				}
			}
		else
			if(strcmp("--pidgin", key) == 0)
				pidgin = True;
		else
			if(strcmp("--limit", key) == 0)
				limit = atoi(value);
		else
			if(strcmp("--gmail", key) == 0)
				gmail = True;
		else
			if(strcmp("--user", key) == 0)
				strcpy(user,value);
		else
			if(strcmp("--passwd", key) == 0)
				strcpy(password,value);
		else
			if(strcmp("--network", key) == 0)
				set_network = True;
		else
			if(strcmp("--eth", key) == 0)
				eth = atoi(value);
		else
			if(strcmp("--wlan", key) == 0)
				wlan = atoi(value);
		else
			if(strcmp("--ppp", key) == 0)
				ppp = atoi(value);
		else
			if(strcmp("--bbcweather", key) == 0) {
				bbccode = atoi(value);
				bbcweather = True;
		}
		else
			if(strcmp("--weather", key) == 0) {
					strcpy(weather_code,value);
					set_weather = True;
			}
		else
			if(strcmp("--weatherplus", key) == 0)
				weatherplus = True;
		else
			if(strcmp("--unit", key) == 0) {
				if(strcmp("F", value) == 0) {
					strcpy(imperial," -i");
					unit = True;
				}
				else
					if(strcmp("C", value) == 0);
				else {
					printf("ERRO: UNIT unavaliable\n");
					exit(0);
				}
			}
		else
			if(strcmp("--ubuntu", key) == 0) {
				strcpy(logo_letter,"u");
				logo = True;
			}
		else
			if(strcmp("--fedora", key) == 0) {
				strcpy(logo_letter,"N");
				logo = True;
			}
		else
			if(strcmp("--arch", key) == 0) {
				strcpy(logo_letter,"B");
				logo = True;
			}
		else
			if(strcmp("--opensuse", key) == 0) {
				strcpy(logo_letter,"h");
				logo = True;
			}
		else
			if(strcmp("--pardus", key) == 0) {
				strcpy(logo_letter,"i");
				logo = True;
			}
		else
			if(strcmp("--debian", key) == 0) {
				strcpy(logo_letter,"J");
				logo = True;
			}
		else
			if(strcmp("--gentoo", key) == 0) {
				strcpy(logo_letter,"Q");
				logo = True;
			}
		else
			if(strcmp("--xfce", key) == 0) {
				strcpy(logo_letter,"y");
				logo = True;
			}
		else
			if(strcmp("--gnome", key) == 0) {
				strcpy(logo_letter,"T");
				logo = True;
			}
		else
			if(strcmp("-h", key) == 0 || strcmp("--help", key) == 0)
				help();
	}
}

//Themes
void themes () {
	if(strcmp("gnome-brave",theme) == 0) {
		strcpy(color1, "3465A4");
		if (alldark == True)
			strcpy(color3, "1E1C1A 1E1C1A");
		else
			if (alllight == True)
				strcpy(color3, "white white");
			else
				strcpy(color3, "204A87 3465A4");
	}
	else
		if(strcmp("gnome-dust",theme) == 0) {
			strcpy(color1, "906E4C");
		if (alldark == True)
			strcpy(color3, "1E1C1A 1E1C1A");
		else
			if (alllight == True)
				strcpy(color3, "white white");
			else
				strcpy(color3, "745536 906E4C");
		}
	else
		if(strcmp("gnome-illustrious",theme) == 0) {
			strcpy(color1, "dc6472");
		if (alldark == True)
			strcpy(color3, "1E1C1A 1E1C1A");
		else
			if (alllight == True)
				strcpy(color3, "white white");
			else
				strcpy(color3, "C6464B DC6472");
		}
	else
		if(strcmp("gnome-noble",theme) == 0) {
			strcpy(color1, "77507b");
		if (alldark == True)
			strcpy(color3, "1E1C1A 1E1C1A");
		else
			if (alllight == True)
				strcpy(color3, "white white");
			else
				strcpy(color3, "5C3566 77507B");
		}
	else
		if(strcmp("gnome-wine",theme) == 0) {
			strcpy(color1, "C22F2F");
		if (alldark == True)
			strcpy(color3, "1E1C1A 1E1C1A");
		else
			if (alllight == True)
				strcpy(color3, "white white");
			else
				strcpy(color3, "A40000 C22F2F");
		}
	else
		if(strcmp("gnome-wise",theme) == 0) {
			strcpy(color1, "709937");
		if (alldark == True)
			strcpy(color3, "1E1C1A 1E1C1A");
		else
			if (alllight == True)
				strcpy(color3, "white white");
			else
				strcpy(color3, "51751E 709937");
		}
	else
		if(strcmp("gnome-carbonite",theme) == 0) {
			strcpy(color1, "555753");
		if (alldark == True)
			strcpy(color3, "1E1C1A 1E1C1A");
		else
			if (alllight == True)
				strcpy(color3, "white white");
			else
				strcpy(color3, "2E3436 555753");
		}
	else
		if(strcmp("gnome-tribute",theme) == 0) {
			strcpy(color1, "9C9E8A");
		if (alldark == True)
			strcpy(color3, "1E1C1A 1E1C1A");
		else
			if (alllight == True)
				strcpy(color3, "white white");
			else
				strcpy(color3, "7D7E60 9C9E8A");
		}
	else
		if(strcmp("shiki-brave",theme) == 0) {
			strcpy(color0, "E6E6E6");
			strcpy(color1, "3465A4");
			strcpy(color2, "E6E6E6");
			strcpy(color3, "204A87 3465A4");
		}
	else
		if(strcmp("shiki-dust",theme) == 0) {
			strcpy(color0, "E6E6E6");
			strcpy(color1, "906E4C");
			strcpy(color2, "E6E6E6");
			strcpy(color3, "745536 906E4C");
		}
	else
		if(strcmp("shiki-human",theme) == 0) {
			strcpy(color0, "E6E6E6");
			strcpy(color1, "E07A1F");
			strcpy(color2, "E6E6E6");
			strcpy(color3, "CE5C00 E07A1F");
		}
	else
		if(strcmp("shiki-illustrious",theme) == 0) {
			strcpy(color0, "E6E6E6");
			strcpy(color1, "dc6472");
			strcpy(color2, "E6E6E6");
			strcpy(color3, "C6464B DC6472");
		}
	else
		if(strcmp("shiki-noble",theme) == 0) {
			strcpy(color0, "E6E6E6");
			strcpy(color1, "77507b");
			strcpy(color2, "E6E6E6");
			strcpy(color3, "5C3566 77507B");
		}
	else
		if(strcmp("shiki-wine",theme) == 0) {
			strcpy(color0, "E6E6E6");
			strcpy(color1, "C22F2F");
			strcpy(color2, "E6E6E6");
			strcpy(color3, "A40000 C22F2F");
		}
	else
		if(strcmp("shiki-wise",theme) == 0) {
			strcpy(color0, "E6E6E6");
			strcpy(color1, "709937");
			strcpy(color2, "E6E6E6");
			strcpy(color3, "51751E 709937");
		}
	else
		if(strcmp("dust",theme) == 0) {
			strcpy(color0, "996B5C");
			strcpy(color1, "996B5C");
			strcpy(color2, "E6E6E6");
			strcpy(color3, "996B5C 996B5C");
		}
	else
		if(custom == True)
			strcpy(color3, color1);
	else {
		strcpy(color1, "E07A1F");
		if (alldark == True)
			strcpy(color3, "1E1C1A 1E1C1A");
		else
			if (alllight == True)
				strcpy(color3, "white white");
			else
				strcpy(color3, "CE5C00 E07A1F");
	}
}

//Languages
void translation () {
	if(strcmp("pt",language) == 0 || strcmp("portuguese",language) == 0){
		strcpy(sys,"SISTEMA");
		strcpy(battery,"Bateria");
		strcpy(uptime,"Atividade");
		strcpy(processes,"Processos");
		strcpy(packages,"Pacotes");
		strcpy(date,"DATA");
		strcpy(photo,"FOTO");
		strcpy(hd,"HD");
		strcpy(temperature,"Temperatura");
		strcpy(updates,"Atualizações");
		strcpy(new,"Novo(s)");
		strcpy(network,"REDE");
		strcpy(up,"Up");
		strcpy(down,"Down");
		strcpy(upload,"Upload");
		strcpy(download,"Download");
		strcpy(signal,"Sinal");
		strcpy(total,"Total");
		strcpy(localip,"Ip local");
		strcpy(publicip,"Ip externo");
		strcpy(nonet,"Rede indisponível");
		strcpy(Weather,"TEMPO");
		strcpy(noweather,"Tempo indisponível");
		strcpy(station,"Estação");
		strcpy(rain,"Chuva");
		strcpy(humidity,"Umidade");
		strcpy(sunrise,"Amanhecer");
		strcpy(sunset,"Anoitecer");
		strcpy(moon,"Lua");
		strcpy(status,"Status");
		strcpy(song,"Música");
		strcpy(time,"Tempo");
		strcpy(nopidgin,"Pidgin não está rodando");
		strcpy(norhythmbox,"Rhythmbox não está rodando");
	}
	else
		if(strcmp("it",language) == 0 || strcmp("italian",language) == 0){
			strcpy(sys,"SISTEMA");
			strcpy(battery,"Batteria");
			strcpy(uptime,"Uptime");
			strcpy(processes,"Processi");
			strcpy(packages,"Pacchetti");
			strcpy(date,"DATA");
			strcpy(photo,"FOTO");
			strcpy(hd,"HD");
			strcpy(temperature,"Temperatura");
			strcpy(updates,"Aggiornamenti");
			strcpy(new,"New");
			strcpy(network,"REDE");
			strcpy(up,"Up");
			strcpy(down,"Down");
			strcpy(upload,"Upload");
			strcpy(download,"Download");
			strcpy(signal,"Segnale");
			strcpy(total,"Totale");
			strcpy(localip,"Ip Locale");
			strcpy(publicip,"Ip Pubblico");
			strcpy(nonet,"Rete Non Disponibile");
			strcpy(Weather,"METEO");
			strcpy(noweather,"Meteo Non Disponibile");
			strcpy(station,"Stazione");
			strcpy(rain,"Pioggia");
			strcpy(humidity,"Umidità");
			strcpy(sunrise,"Alba");
			strcpy(sunset,"Tramonto");
			strcpy(moon,"Luna");
			strcpy(status,"Status");
			strcpy(song,"Canzone");
			strcpy(time,"Tempo");
			strcpy(nopidgin,"Pidgin non è in esecuzione");
			strcpy(norhythmbox,"Rhythmbox non è in esecuzione");
	}
	else
		if(strcmp("es",language) == 0 || strcmp("spanish",language) == 0){
			strcpy(sys,"SISTEMA");
			strcpy(battery,"Batería");
			strcpy(uptime,"Actividad");
			strcpy(processes,"Procesos");
			strcpy(packages,"Paquetes");
			strcpy(date,"FECHA");
			strcpy(photo,"FOTO");
			strcpy(hd,"HD");
			strcpy(temperature,"Temperatura");
			strcpy(updates,"Actualizaciones");
			strcpy(new,"Nuevo(s)");
			strcpy(network,"RED");
			strcpy(up,"Envío");
			strcpy(down,"Recibo");
			strcpy(upload,"Enviado");
			strcpy(download,"Recibido");
			strcpy(signal,"Señal");
			strcpy(total,"Total");
			strcpy(localip,"Ip Local");
			strcpy(publicip,"Ip Pública");
			strcpy(nonet,"Red no disponible");
			strcpy(Weather,"CLIMA");
			strcpy(noweather,"Clima no disponible");
			strcpy(station,"Estación");
			strcpy(rain,"Lluvia");
			strcpy(humidity,"Humedad");
			strcpy(sunrise,"Amanecer");
			strcpy(sunset,"Anochecer");
			strcpy(moon,"Luna");
			strcpy(status,"Situación");
			strcpy(song,"Canción");
			strcpy(time,"Tiempo");
			strcpy(nopidgin,"Pidgin no esta corriendo");
			strcpy(norhythmbox,"Rhythmbox no esta corriendo");
		}
	else
		if(strcmp("de",language) == 0 || strcmp("deutsch",language) == 0){
			strcpy(sys,"SYSTEM");
			strcpy(battery,"Batterie");
			strcpy(uptime,"Uptime");
			strcpy(processes,"Prozesse");
			strcpy(packages,"Pakete");
			strcpy(date,"DATUM");
			strcpy(photo,"PHOTO");
			strcpy(hd,"HD");
			strcpy(temperature,"Temperatur");
			strcpy(updates,"Updates");
			strcpy(new,"New");
			strcpy(network,"NETZWERK");
			strcpy(up,"Up");
			strcpy(down,"Down");
			strcpy(upload,"Upload");
			strcpy(download,"Download");
			strcpy(signal,"Signal");
			strcpy(total,"Insgesamt");
			strcpy(localip,"Lokale IP");
			strcpy(publicip,"Öffentliche IP");
			strcpy(nonet,"Netzwerk nicht verfügbar");
			strcpy(Weather,"WETTER");
			strcpy(noweather,"Wetter nicht verfügbar");
			strcpy(station,"Station");
			strcpy(rain,"Regen");
			strcpy(humidity,"Feuchte");
			strcpy(sunrise,"Sonnenaufgang");
			strcpy(sunset,"Sonnenuntergang");
			strcpy(moon,"Mond");
			strcpy(status,"Status");
			strcpy(song,"Gesang");
			strcpy(time,"Zeit");
			strcpy(nopidgin,"Pidgin nicht läuft");
			strcpy(norhythmbox,"Rhythmbox nicht läuft");
		}
	else
		if(strcmp("pl",language) == 0 || strcmp("polish",language) == 0) {
			strcpy(sys,"SYSTEM");
			strcpy(battery,"Bateria");
			strcpy(uptime,"Uruchomiony");
			strcpy(processes,"Procesów");
			strcpy(packages,"Pakiety");
			strcpy(date,"DATA");
			strcpy(photo,"ZDJĘCIE");
			strcpy(hd,"DYSKI");
			strcpy(temperature,"Temperatura");
			strcpy(updates,"Aktualizacje");
			strcpy(new,"Nowe");
			strcpy(network,"SIEĆ");
			strcpy(up,"Wys.");
			strcpy(down,"Pob.");
			strcpy(upload,"Wysłano");
			strcpy(download,"Pobrano");
			strcpy(signal,"Sygnał");
			strcpy(total,"Oddanych");
			strcpy(localip,"Lokalne IP");
			strcpy(publicip,"Publiczne IP");
			strcpy(nonet,"Sieć Niedostępna");
			strcpy(Weather,"POGODA");
			strcpy(noweather,"Pogoda niedostępna");
			strcpy(station,"Dworzec");
			strcpy(rain,"Deszcz");
			strcpy(humidity,"Wilgotność");
			strcpy(sunrise,"Świt");
			strcpy(sunset,"Zachód słońca");
			strcpy(moon,"Księżyc");
			strcpy(status,"Stan");
			strcpy(song,"Utwór");
			strcpy(time,"Pozycja");
			strcpy(nopidgin,"Pidgin nie działa");
			strcpy(norhythmbox,"Rhythmbox nie działa");
		}
	else
		if(strcmp("et",language) == 0 || strcmp("estonian",language) == 0){
			strcpy(sys,"SÜSTEEM");
			strcpy(battery,"Aku");
			strcpy(uptime,"Tööaeg");
			strcpy(processes,"Protsessid");
			strcpy(packages,"Pakendid");
			strcpy(date,"KUUPÄEV");
			strcpy(photo,"FOTO");
			strcpy(hd,"KÕVAKETAS");
			strcpy(temperature,"Temperatuur");
			strcpy(updates,"Uuendused");
			strcpy(new,"uut");
			strcpy(network,"VÕRK");
			strcpy(up,"Üles");
			strcpy(down,"Alla");
			strcpy(upload,"Üleslaetud");
			strcpy(download,"Allalaetud");
			strcpy(signal,"Signaal");
			strcpy(total,"Kokku");
			strcpy(localip,"Kohalik IP");
			strcpy(publicip,"Avalik IP");
			strcpy(nonet,"Võrk pole saadaval");
			strcpy(Weather,"ILM");
			strcpy(noweather,"Ilm pole saadaval");
			strcpy(station,"Jaam");
			strcpy(rain,"Vihm");
			strcpy(humidity,"Niiskus");
			strcpy(sunrise,"Päikesetõus");
			strcpy(sunset,"Päikeseloojangu");
			strcpy(moon,"Kuu");
			strcpy(status,"Staatus");
			strcpy(song,"Laul");
			strcpy(time,"Aeg");
			strcpy(nopidgin,"Pidgin ei tööta");
			strcpy(norhythmbox,"Rhythmbox ei tööta");
		}
	else
		if(strcmp("ru",language) == 0 || strcmp("russian",language) == 0) {
			strcpy(sys,"СИСТЕМА");
			strcpy(battery,"Батарея");
			strcpy(uptime,"Время работы");
			strcpy(processes,"Процессы");
			strcpy(packages,"Пакеты");
			strcpy(date,"ДАТА");
			strcpy(photo,"ФОТО");
			strcpy(hd,"ДИСКИ");
			strcpy(temperature,"Температура");
			strcpy(updates,"Обновления");
			strcpy(new,"Новое");
			strcpy(network,"СЕТЬ");
			strcpy(up,"Отправка");
			strcpy(down,"Приём");
			strcpy(upload,"Всего отправлено");
			strcpy(download,"Всего получено");
			strcpy(signal,"Сигнал");
			strcpy(total,"Всего");
			strcpy(localip,"Локальный IP");
			strcpy(publicip,"Внешний IP");
			strcpy(nonet,"Сеть недоступна");
			strcpy(Weather,"ПОГОДА");
			strcpy(noweather,"Информация о погоде недоступна");
			strcpy(station,"Станция");
			strcpy(rain,"Дождь");
			strcpy(humidity,"Влажность");
			strcpy(sunrise,"Восход");
			strcpy(sunset,"Закат");
			strcpy(moon,"Луна");
			strcpy(status,"Статус");
			strcpy(song,"Композиция");
			strcpy(time,"Время");
			strcpy(nopidgin,"Pidgin не запущен");
			strcpy(norhythmbox,"Rhythmbox не запущен");
		}
	else
		if(strcmp("bg",language) == 0 || strcmp("bulgarian",language) == 0) {
			strcpy(sys,"СИСТЕМА");
			strcpy(battery,"Батерия");
			strcpy(uptime,"Време на работа");
			strcpy(processes,"Процеси");
			strcpy(packages,"пакет(а)");
			strcpy(date,"ДАТА");
			strcpy(photo,"СНИМКА");
			strcpy(hd,"ТВЪРД ДИСК");
			strcpy(temperature,"Температура");
			strcpy(updates,"Актуализации");
			strcpy(new,"Нови");
			strcpy(network,"МРЕЖА");
			strcpy(up,"Качване");
			strcpy(down,"Сваляне");
			strcpy(upload,"Качено");
			strcpy(download,"Свалено");
			strcpy(signal,"Сила на сигнала");
			strcpy(total,"Общо");
			strcpy(localip,"Локален IP");
			strcpy(publicip,"Външен IP");
			strcpy(nonet,"Мрежата е недостъпна");
			strcpy(Weather,"ВРЕМЕТО");
			strcpy(noweather,"Няма информация за времето");
			strcpy(station,"станция");
			strcpy(rain,"дъжд");
			strcpy(humidity,"влажност");
			strcpy(sunrise,"изгрев");
			strcpy(sunset,"залез");
			strcpy(moon,"луна");
			strcpy(status,"Статус");
			strcpy(song,"Песен");
			strcpy(time,"Време");
			strcpy(nopidgin,"Pidgin не е стартиран");
			strcpy(norhythmbox,"Rhythmbox не е стартиран");
		}
		else {
			strcpy(sys,"SYSTEM");
			strcpy(battery,"Battery");
			strcpy(uptime,"Uptime");
			strcpy(processes,"Processes");
			strcpy(packages,"Packages");
			strcpy(date,"DATE");
			strcpy(photo,"PHOTO");
			strcpy(hd,"HD");
			strcpy(temperature,"Temperature");
			strcpy(updates,"Updates");
			strcpy(new,"New");
			strcpy(network,"NETWORK");
			strcpy(up,"Up");
			strcpy(down,"Down");
			strcpy(upload,"Upload");
			strcpy(download,"Download");
			strcpy(signal,"Signal");
			strcpy(total,"Total");
			strcpy(localip,"Local IP");
			strcpy(publicip,"Public IP");
			strcpy(nonet,"Network Unavailable");
			strcpy(Weather,"WEATHER");
			strcpy(noweather,"Weather Unavailable");
			strcpy(station,"Station");
			strcpy(rain,"Rain");
			strcpy(humidity,"Humidity");
			strcpy(sunrise,"Sunrise");
			strcpy(sunset,"Sunset");
			strcpy(moon,"Moon");
			strcpy(status,"Status");
			strcpy(song,"Song");
			strcpy(time,"Time");
			strcpy(nopidgin,"Pidgin not running");
			strcpy(norhythmbox,"Rhythmbox not running");
		}
}

//Photo Position
void photoposition () {
	if (cpu == 1)
		yp += 120;
	else {
		yp += 108;
		for (i = True; i <= cpu; i++)
		yp += 12;
	}
	if (aptget == True)
		yp += 13;
	if (gmail == True && pidgin == False)
		yp += 13;
	if (set_battery == True)
		yp += 18;
	if (swap == True)
		yp += 30;
	if (set_process == True) {
		yp += 18;
		for (i = True; i <= proc; i++)
		yp += 12;
	}
	if (nodata == False) {
		if (clocktype == 1)
			yp += 156;
			else
				if (clocktype == 2)
					yp += 174;
			else
				if (clocktype == 3)
					yp += 65;
			else
				if (clocktype == 4)
					yp += 84;
			else
				if (clocktype == 5)
					yp += 34;
			else
				yp += 68;
		if (set_calendar == True)
			yp += 82;
	}
}

void coverposition () {
	if (cpu == 1)
		yc += 139;
	else {
		yc += 125;
		for (i = True; i <= cpu; i++)
		yc += 12;
	}
	if (aptget == True)
		yc += 13;
	if (gmail == True && pidgin == False)
		yc += 13;
	if (set_battery == True)
		yc += 18;
	if (swap == True)
		yc += 31;
	if (set_process == True) {
		yc += 18;
		for (i = True; i <= proc; i++)
		yc += 12;
	}
	if (nodata == False) {
		if (clocktype == 1)
			yc += 156;
			else
				if (clocktype == 2)
					yc += 174;
			else
				if (clocktype == 3)
					yc += 65;
			else
				if (clocktype == 4)
					yc += 84;
			else
				if (clocktype == 5)
					yc += 34;
			else
				yc += 68;
		if (set_calendar == True)
			yc += 82;
	}
	if (set_photo == 1 || set_photo == 2) {
		yc += 142;
	}
	if (cover == 3 || cover == 6 || cover == 7)
		yc -= 2;
}

//Create and write conkyForecast.template
void conkyforecast () {

	FILE *fp;

	fp = fopen("conkyForecast.template", "w");

	fprintf(fp,"${voffset -10}${alignr 56}${color2}${font ConkyWeather:style=Bold:size=40}[--datatype=WF]${font}${color}\n");
	fprintf(fp,"${voffset -50}${color2}${font Weather:size=40}y${font}${color2}  ${voffset -38}${color2}${font Arial Black:size=26}[--datatype=HT]${font}${color}\n");
	fprintf(fp,"${voffset 2}\n");
	if (shiki==1 || shikidust==1 || dust ==1)
		fprintf(fp,"${voffset 0}${goto 16}[--datatype=DW --startday=1 --shortweekday] ${goto 64}[--datatype=DW --startday=2 --shortweekday] ${goto 112}[--datatype=DW --startday=3 --shortweekday] ${goto 156}[--datatype=DW --startday=4 --shortweekday]\n");
	else
		fprintf(fp,"${voffset 0}${goto 13}[--datatype=DW --startday=1 --shortweekday] ${goto 59}[--datatype=DW --startday=2 --shortweekday] ${goto 105}[--datatype=DW --startday=3 --shortweekday] ${goto 150}[--datatype=DW --startday=4 --shortweekday]\n");
	fprintf(fp,"${voffset 0}${color2}${font ConkyWeather:size=28}[--datatype=WF --startday=1 --endday=4 --spaces=1]${font}${color}\n");
	if (shiki==1 || shikidust==1 || dust ==1)
		fprintf(fp,"${voffset 0}${goto 14}[--datatype=HT --startday=1 --hideunits --centeredwidth=3]/[--datatype=LT --startday=1 --hideunits --centeredwidth=3] ${goto 59}[--datatype=HT --startday=2 --hideunits --centeredwidth=3]/[--datatype=LT --startday=2 --hideunits --centeredwidth=3] ${goto 104}[--datatype=HT --startday=3 --hideunits --centeredwidth=3]/[--datatype=LT --startday=3 --hideunits --centeredwidth=3] ${goto 151}[--datatype=HT --startday=4 --hideunits --centeredwidth=3]/[--datatype=LT --startday=4 --hideunits --centeredwidth=3]\n");
	else
		fprintf(fp,"${voffset 0}${goto 8}[--datatype=HT --startday=1 --hideunits --centeredwidth=3]/[--datatype=LT --startday=1 --hideunits --centeredwidth=3] ${goto 53}[--datatype=HT --startday=2 --hideunits --centeredwidth=3]/[--datatype=LT --startday=2 --hideunits --centeredwidth=3] ${goto 98}[--datatype=HT --startday=3 --hideunits --centeredwidth=3]/[--datatype=LT --startday=3 --hideunits --centeredwidth=3] ${goto 145}[--datatype=HT --startday=4 --hideunits --centeredwidth=3]/[--datatype=LT --startday=4 --hideunits --centeredwidth=3]\n");
	if (weatherplus == True) {
		fprintf(fp,"${voffset 5}${goto 12}${font Moon Phases:style=Bold:size=36}${color2}[--datatype=MF]${color}${font}\n");
		fprintf(fp,"${voffset 6}${goto 10}${font ConkyWindNESW:size=40}${color2}[--datatype=BS]${color}${font}\n");
		fprintf(fp,"${voffset 4}${goto 22}[--datatype=WS]\n");
		fprintf(fp,"${voffset -116}${goto 70}${font Liberation Sans Mono:style=Bold:size=10}${color2}[--datatype=CT]${color}${font}\n");
		fprintf(fp,"${voffset 8}${goto 70}%s: [--datatype=OB]\n", station);
		fprintf(fp,"${goto 70}%s: [--datatype=PC]\n", rain);
		fprintf(fp,"${goto 70}UV: [--datatype=UI] - [--datatype=UT]\n");
		fprintf(fp,"${goto 70}%s: [--datatype=HM]\n", humidity);
		fprintf(fp,"${goto 70}%s: [--datatype=SR]\n", sunrise);
		fprintf(fp,"${goto 70}%s: [--datatype=SS]\n", sunset);
		fprintf(fp,"${goto 70}%s: [--datatype=MP]\n", moon);
	}
	fprintf(fp,"${voffset -10}");

	fclose(fp);
}


//Create and write conkyPlayer.template
void conkyplayer () {

	FILE *fp;

	fp = fopen("conkyPlayer.template", "w");

	if (cover == 7) {
			fprintf(fp,"${image /tmp/conkyCover.png -s 79x58 -p 22,%d}${voffset 4}${color0}${font Musicelements:size=18}z${font}${color}${voffset -8}${goto %d}%s:${alignr}${color2}[--datatype=ST]${color}\n", yc, go2, status);
			fprintf(fp,"${voffset 4}${goto 110}${color2}[--datatype=AR]${color}\n");
			fprintf(fp,"${goto 110}${color2}[--datatype=AL]${color}\n");
			fprintf(fp,"${goto 110}${color2}[--datatype=TI]${color}\n");
			fprintf(fp,"${goto 110}${color2}[--datatype=PT]/[--datatype=LE]${color}");
	}
	else
		if (cover == 6) {
			fprintf(fp,"${image /tmp/conkyCover.png -s 68x60 -p 24,%d}${voffset 4}${color0}${font Musicelements:size=18}z${font}${color}${voffset -8}${goto %d}%s:${alignr}${color2}[--datatype=ST]${color}\n", yc, go2, status);
			fprintf(fp,"${voffset 4}${goto 100}${color2}[--datatype=AR]${color}\n");
			fprintf(fp,"${goto 100}${color2}[--datatype=AL]${color}\n");
			fprintf(fp,"${goto 100}${color2}[--datatype=TI]${color}\n");
			fprintf(fp,"${goto 100}${color2}[--datatype=PT]/[--datatype=LE]${color}");
		}
	else
		if (cover == 5) {
			fprintf(fp,"${image /tmp/conkyCover.png -s 68x55 -p 24,%d}${voffset 4}${color0}${font Musicelements:size=18}z${font}${color}${voffset -8}${goto %d}%s:${alignr}${color2}[--datatype=ST]${color}\n", yc, go2, status);
			fprintf(fp,"${voffset 4}${goto 100}${color2}[--datatype=AR]${color}\n");
			fprintf(fp,"${goto 100}${color2}[--datatype=AL]${color}\n");
			fprintf(fp,"${goto 100}${color2}[--datatype=TI]${color}\n");
			fprintf(fp,"${goto 100}${color2}[--datatype=PT]/[--datatype=LE]${color}");
		}
	else
		if (cover == 4) {
			fprintf(fp,"${image /tmp/conkyCover.png -s 63x55 -p 24,%d}${voffset 4}${color0}${font Musicelements:size=18}z${font}${color}${voffset -8}${goto %d}%s:${alignr}${color2}[--datatype=ST]${color}\n", yc, go2, status);
			fprintf(fp,"${voffset 4}${goto 95}${color2}[--datatype=AR]${color}\n");
			fprintf(fp,"${goto 95}${color2}[--datatype=AL]${color}\n");
			fprintf(fp,"${goto 95}${color2}[--datatype=TI]${color}\n");
			fprintf(fp,"${goto 95}${color2}[--datatype=PT]/[--datatype=LE]${color}");
		}
	else
		if (cover == 3) {
			fprintf(fp,"${image /tmp/conkyCover.png -s 88x62 -p 16,%d}${voffset 4}${color0}${font Musicelements:size=18}z${font}${color}${voffset -8}${goto %d}%s:${alignr}${color2}[--datatype=ST]${color}\n", yc, go2, status);
			fprintf(fp,"${voffset 4}${goto 104}${color2}[--datatype=AR]${color}\n");
			fprintf(fp,"${goto 104}${color2}[--datatype=AL]${color}\n");
			fprintf(fp,"${goto 104}${color2}[--datatype=TI]${color}\n");
			fprintf(fp,"${goto 104}${color2}[--datatype=PT]/[--datatype=LE]${color}");
		}
	else
		if (cover == 2) {
			fprintf(fp,"${voffset 4}${color0}${font Musicelements:size=18}z${font}${color}${voffset -8}${goto %d}%s:${alignr}${color2}[--datatype=ST]${color}\n", go2, status);
			fprintf(fp,"${voffset 4}${goto %d}${color2}[--datatype=AR]${color}\n", go2);
			fprintf(fp,"${color2}${goto %d}[--datatype=AL]${color}\n", go2);
			fprintf(fp,"${color2}${goto %d}[--datatype=TI]${color}\n", go2);
			fprintf(fp,"${voffset 4}${goto %d}${color2}[--datatype=PT]/[--datatype=LE]${color}", go2);
			if (banshee == True)
				fprintf(fp,"${alignr}${color2}${execbar ~/.conkycolors/bin/conkyBanshee --datatype=PP}${color}");
			else
				if (rhythmbox == True)
					fprintf(fp,"${alignr}${color2}${execbar ~/.conkycolors/bin/conkyRhythmbox --datatype=PP}${color}");
				else
					fprintf(fp,"${alignr}${color2}${execbar ~/.conkycolors/bin/conkyExaile --datatype=PP}${color}");
		}
		else {
			fprintf(fp,"${voffset 2}${color0}${font Webdings:size=16}U${font}${color}${voffset -2}${goto %d}%s:${alignr}${color2}[--datatype=ST]${color}\n", go2, status);
			fprintf(fp,"${voffset 4}${color0}${font Musicelements:size=19}z${font}${color}${voffset -8}${goto %d}%s:${alignr}${color2}[--datatype=AR]${color}\n", go2, song);
			fprintf(fp,"${color2}${alignr}[--datatype=AL]${color}\n");
			fprintf(fp,"${color2}${alignr}[--datatype=TI]${color}\n");
			fprintf(fp,"${voffset -7}${color0}${font Martin Vogel's Symbols:size=19}U${font}${color}${voffset -4}${goto %d}%s:${alignr}${color2}[--datatype=PT]/[--datatype=LE]${color}", go2, time);
		}

	fclose(fp);
}

//Create and write conkyCover
void conkycover () {

	FILE *fp;

	fp = fopen("conkyCover", "w");
	fprintf(fp,"#!/bin/bash\n");
	fprintf(fp,"#\n");
	fprintf(fp,"# Album art with cd theme in conky\n");
	fprintf(fp,"# by helmuthdu\n\n");
	if (banshee == True) {
		fprintf(fp,"player=\"`~/.conkycolors/bin/conkyBanshee --datatype=CA | sed -e 's/\\\\\\//g'`\"\n");
		fprintf(fp,"icon=~/.conkycolors/icons/Players/banshee.png\n");
	}
	else if (rhythmbox == True) {
		fprintf(fp,"player=\"`~/.conkycolors/bin/conkyRhythmbox --datatype=CA | sed 's/[%%20 ]\\+/\\\\ /g'`\"\n");
		fprintf(fp,"icon=~/.conkycolors/icons/Players/rhythmbox.png\n");
	}
	else {
		fprintf(fp,"player=\"`~/.conkycolors/bin/conkyExaile --datatype=CA | sed -e 's/\\\\\\//g'`\"\n");
		fprintf(fp,"icon=~/.conkycolors/icons/Players/exaile.png\n");
	}
	fprintf(fp,"cover=/tmp/conkyCover.png\n");
	fprintf(fp,"\n");
	fprintf(fp,"if [ ! -f \"$player\" ]; then\n");
	if (cover == 4) {
		fprintf(fp,"\t#cp $icon $cover\n");
		fprintf(fp,"\tconvert ~/.conkycolors/icons/CD/base.png ~/.conkycolors/icons/CD/top.png -geometry +0+0 -composite $cover\n");
	}
	else
		if (cover == 5) {
			fprintf(fp,"\tconvert ~/.conkycolors/icons/Case/base.png ~/.conkycolors/icons/Case/top.png -geometry +0+0 -composite $cover\n");
		}
	else
		if (cover == 6) {
			fprintf(fp,"\tconvert ~/.conkycolors/icons/Glassy/base.png ~/.conkycolors/icons/Glassy/top.png -geometry +0+0 -composite $cover\n");
		}
	else
		if (cover == 7) {
			fprintf(fp,"\tconvert ~/.conkycolors/icons/oldVinyl/base.png ~/.conkycolors/icons/oldVinyl/top.png -geometry +0+0 -composite $cover\n");
		}
	else
		fprintf(fp,"\tconvert ~/.conkycolors/icons/Vinyl/base.png $icon -geometry +36+18 -composite $cover\n");
	fprintf(fp,"else\n");
	if (cover == 4) {
		fprintf(fp,"\tconvert \"$player\" -thumbnail 98x98 $cover\n");
		fprintf(fp,"\tconvert ~/.conkycolors/icons/CD/base.png $cover -geometry +19+5 -composite ~/.conkycolors/icons/CD/top.png -geometry +0+0 -composite $cover\n");
	}
	else
		if (cover == 5) {
			fprintf(fp,"\tconvert \"$player\" -thumbnail 99x99 $cover\n");
			fprintf(fp,"\tconvert ~/.conkycolors/icons/Case/base.png $cover -geometry +8+2 -composite ~/.conkycolors/icons/Case/top.png -geometry +0+0 -composite $cover\n");
		}
	else
		if (cover == 6) {
			fprintf(fp,"\tconvert \"$player\" -thumbnail 92x92 $cover\n");
			fprintf(fp,"\tconvert ~/.conkycolors/icons/Glassy/base.png $cover -geometry +23+8 -composite ~/.conkycolors/icons/Glassy/top.png -geometry +0+0 -composite $cover\n");
		}
	else
		if (cover == 7) {
		fprintf(fp,"\tconvert \"$player\" -thumbnail 86x86 $cover\n");
		fprintf(fp,"\tconvert ~/.conkycolors/icons/oldVinyl/base.png $cover -geometry +4+3 -composite ~/.conkycolors/icons/oldVinyl/top.png -geometry +0+0 -composite $cover\n");
		}
	else {
		fprintf(fp,"\tconvert \"$player\" -thumbnail 112x112 $cover\n");
		fprintf(fp,"\tconvert ~/.conkycolors/icons/Vinyl/base.png $cover -geometry +32+6 -composite ~/.conkycolors/icons/Vinyl/top.png -geometry +0+0 -composite $cover\n");
	}
	fprintf(fp,"fi\n");
	fprintf(fp,"\n");
	fprintf(fp,"exit 0\n");

	fclose(fp);
}

//Create and write .conkyrc
void conkyrc () {

	FILE *fp;

	fp = fopen("conkyrc", "w");

	//Global Setup
	fprintf(fp,"use_xft yes\n");
	fprintf(fp,"xftfont Liberation Sans:size=8\n");
	fprintf(fp,"override_utf8_locale yes\n");
	fprintf(fp,"\n");
	fprintf(fp,"text_buffer_size 2048\n");
	fprintf(fp,"update_interval 1\n");
	fprintf(fp,"total_run_times 0\n");
	fprintf(fp,"double_buffer yes\n");
	fprintf(fp,"no_buffers yes\n");
	fprintf(fp,"net_avg_samples 1\n");
	fprintf(fp,"cpu_avg_samples 1\n");
	fprintf(fp,"\n");
	fprintf(fp,"own_window_class Conky\n");
	fprintf(fp,"own_window yes\n");
	if (shiki == True)
		fprintf(fp,"own_window_colour 3C3C3C\n");
	else
		if (shikidust == True)
			fprintf(fp,"own_window_colour 464139\n");
		else
			if (dust == True)
				fprintf(fp,"own_window_colour 2C2B29\n");
	fprintf(fp,"own_window_type override\n");
	if (shiki == True || shikidust == True || dust == True)
		fprintf(fp,"own_window_transparent no\n");
	else
		fprintf(fp,"own_window_transparent yes\n");
	fprintf(fp,"own_window_hints undecorated,below,sticky,skip_taskbar,skip_pager\n");
	fprintf(fp,"\n");
	if (shiki == True || shikidust == True || dust == True) {
		if (shikidust == True)
			fprintf(fp,"default_color D1CCC4\n");
		else
			if (dust == True)
				fprintf(fp,"default_color 929292\n");
			else
				fprintf(fp,"default_color D8D8D8\n");
		fprintf(fp,"draw_borders yes\n");
		fprintf(fp,"border_width 1\n");
		fprintf(fp,"border_margin 10\n");
		fprintf(fp,"draw_graph_borders yes\n");
		fprintf(fp,"draw_outline no\n");
	}
	else
		if(custom == True)
				fprintf(fp,"default_color %s\n", defaultcolor);
		else
			if(dark == True || alldark == True)
				fprintf(fp,"default_color 212526\n");
		else
			fprintf(fp,"default_color cccccc\n");
	fprintf(fp,"draw_shades no\n");
	fprintf(fp,"\n");
	if (shiki == True || shikidust == True || dust == True)
		fprintf(fp,"color0 %s\n", color0);
	else
		if (custom == True)
			fprintf(fp,"color0 %s\n", color0);
		else
			if (dark == True || alldark == True)
				fprintf(fp,"color0 1E1C1A\n");
		else
			fprintf(fp,"color0 white\n");
	if (custom == True)
		fprintf(fp,"color1 %s\n", color1);
	else
		if (alldark == True)
			fprintf(fp,"color1 1E1C1A\n");
		else
			if (alllight == True)
				fprintf(fp,"color1 white\n");
		else
			fprintf(fp,"color1 %s\n", color1);
	if (shiki == True || shikidust == True || dust == True)
		fprintf(fp,"color2 %s\n", color2);
	else
		if (custom == True)
			fprintf(fp,"color2 %s\n", color2);
		else
			if (dark == True || alldark == True)
				fprintf(fp,"color2 1E1C1A\n");
		else
			fprintf(fp,"color2 white\n");
	fprintf(fp,"\n");
	if(strcmp("left",side) == 0)
		fprintf(fp,"alignment top_left\n");
	else
		fprintf(fp,"alignment top_right\n");
	fprintf(fp,"gap_x 25\n");
	if (shiki == True || shikidust == True || dust == True)
		fprintf(fp,"gap_y 50\n");
	else
		fprintf(fp,"gap_y 40\n");
	fprintf(fp,"minimum_size 182 0\n");
	fprintf(fp,"maximum_width 182\n");
	fprintf(fp,"\n");
	fprintf(fp,"default_bar_size 60 8\n");
	fprintf(fp,"\n");
	fprintf(fp,"imlib_cache_size 0\n");
	fprintf(fp,"\n");
	fprintf(fp,"TEXT\n");

	//System Widget
	fprintf(fp,"${font Liberation Sans:style=Bold:size=8}%s $stippled_hr${font}\n", sys);
	if (logo == True) {
		fprintf(fp,"${color0}${voffset 6}${font OpenLogos:size=19}%s${font}${color}", logo_letter);
		fprintf(fp,"${goto %d}${voffset -14}Kernel:  ${alignr}${color2}${kernel}${color}\n", go2);
	}
	else {
		fprintf(fp,"${color0}${font Poky:size=15}S${font}${color}");
		fprintf(fp,"${goto %d}${voffset -8}Kernel:  ${alignr}${color2}${kernel}${color}\n", go2);
	}
	fprintf(fp,"${goto %d}%s: ${alignr}${color2}${uptime}${color}\n", go2, uptime);
	if (aptget == True)
		fprintf(fp,"${goto %d}%s: ${alignr}${font Liberation Sans:style=Bold:size=8}${color1}${execi 360 aptitude search \"~U\" | wc -l | tail}${color}${font} ${color2}%s${color}\n", go2, updates, packages);
	if (gmail == True && pidgin == False)
		fprintf(fp,"${goto %d}Gmail: ${alignr}${font Liberation Sans:style=Bold:size=8}${color0}${execpi 3600 ~/.conkycolors/bin/conkyEmail --servertype=IMAP --servername=imap.googlemail.com -u %s -p %s --ssl}${color}${font} %s email(s)\n", go2, user, password, new);
	if (cpu == 1) {
		fprintf(fp,"${offset 1}${color0}${font Poky:size=16}P${color}${font}${voffset -4}");
		if (cputemp == True) {
			if (unit == True)
				fprintf(fp,"${goto %d}CPU: ${font Liberation Sans:style=Bold:size=8}${color1}${cpu cpu1}%%${font} ${alignr}${font Liberation Sans:style=Bold:size=8}${color1}${execi 30 sensors -f | grep 'CPU Temperature' | cut -c14-16}°F${color}${font}  ${color2}${cpugraph cpu1 8,50 %s}${color}\n", go2, color3);
			else
				fprintf(fp,"${goto %d}CPU: ${font Liberation Sans:style=Bold:size=8}${color1}${cpu cpu1}%%${font} ${alignr}${font Liberation Sans:style=Bold:size=8}${color1}${execi 30 sensors | grep 'CPU Temperature' | cut -c15-16}°C${color}${font}  ${color2}${cpugraph cpu1 8,50 %s}${color}\n", go2, color3);
		}
		else
			fprintf(fp,"${goto %d}CPU: ${font Liberation Sans:style=Bold:size=8}${color1}${cpu cpu1}%%${color}${font} ${alignr}${color2}${cpugraph cpu1 8,60 %s}${color}\n", go2, color3);
	}
	else {
		fprintf(fp,"${offset 1}${color0}${font Poky:size=16}P${font}${offset -19}${voffset 9}${cpubar cpu0 4,18}${color}${voffset -16}");
		for (i = True; i <= cpu; i++) {
			if (cputemp == True) {
				if (unit == True)
					fprintf(fp,"${goto %d}CPU%d: ${font Liberation Sans:style=Bold:size=8}${color1}${cpu cpu%d}%%${font} ${alignr}${font Liberation Sans:style=Bold:size=8}${color1}${execi 30 sensors -f | grep 'Core %d' | cut -c14-16}°F${color}${font}  ${color2}${cpugraph cpu%d 8,50 %s}${color}\n", go2, i, i, i-1, i, color3);
				else
					fprintf(fp,"${goto %d}CPU%d: ${font Liberation Sans:style=Bold:size=8}${color1}${cpu cpu%d}%%${font} ${alignr}${font Liberation Sans:style=Bold:size=8}${color1}${execi 30 sensors | grep 'Core %d' | cut -c15-16}°C${color}${font}  ${color2}${cpugraph cpu%d 8,50 %s}${color}\n", go2, i, i, i-1, i, color3);
			}
			else
				fprintf(fp,"${goto %d}CPU%d: ${font Liberation Sans:style=Bold:size=8}${color1}${cpu cpu%d}%%${color}${font} ${alignr}${color2}${cpugraph cpu%d 8,60 %s}${color}\n", go2, i, i, i, color3);
		}
	}
	fprintf(fp,"${color0}${font Poky:size=16}M${font}${color}${goto %d}${voffset -7}RAM: ${font Liberation Sans:style=Bold:size=8}${color1}$memperc%%${color}${font}\n", go2);
	fprintf(fp,"${offset 1}${voffset 2}${color2}${membar 4,18}${color}${goto %d}${voffset -2}F: ${color2}${memeasyfree}${color} U: ${color2}${mem}${color}\n", go2);
	if (swap == True) {
		fprintf(fp,"${voffset 2}${color0}${font Poky:size=14}s${font}${color}${voffset -8}${goto %d}SWAP: ${font Liberation Sans:style=Bold:size=8}${color1}${swapperc}%%${color}${font}\n", go2);
		fprintf(fp,"${voffset 4}${offset 1}${color2}${swapbar 4,18}${color}${voffset -4}${goto %d}F: ${color2}$swapmax${color} U: ${color2}$swap${color}\n", go2);
	}
	if (set_battery == True)
		fprintf(fp,"${color0}${font Poky:size=13}E${font}${color}${goto %d}${voffset -5}%s: ${font Liberation Sans:style=Bold:size=8}${color1}${battery_percent BAT0}%%${color}${font} ${alignr}${color2}${battery_bar 8,60 BAT0}${color}\n", go2, battery);
	if (set_process == True) {
		fprintf(fp,"${voffset 2}${color0}${font Poky:size=15}a${font}${color}${goto %d}${voffset -10}%s: ${color2}${alignr 13}CPU${alignr}RAM${color}\n", go2, processes);
		for (i = True; i <= proc; i++)
			if (shiki == True || shikidust == True || dust == True)
				fprintf(fp,"${voffset -1}${goto 46}${color2}${top name %d}${color}${font Liberation Sans:style=Bold:size=8}${color1} ${goto 127}${top cpu %d}${alignr }${top mem %d}${color}${font}\n", i, i, i);
			else
				fprintf(fp,"${voffset -1}${goto 42}${color2}${top name %d}${color}${font Liberation Sans:style=Bold:size=8}${color1} ${goto 124}${top cpu %d}${alignr }${top mem %d}${color}${font}\n", i, i, i);
	}

	//Clock and Calendar Widget
	if (nodata == False) {
		fprintf(fp,"${voffset 4}${font Liberation Sans:style=Bold:size=8}%s $stippled_hr${font}\n", date);
		if (clocktype == 1) {
			fprintf(fp,"${voffset 10}${alignc 55}${font aClock:style=_Hour:size=90}${color2}${execpi 120 ~/.conkycolors/bin/conkyClock_h}${color}${font}\n");
			fprintf(fp,"${voffset -98}${alignc 55}${font aClock:style=_Min:size=90}${color2}${execpi 60 ~/.conkycolors/bin/conkyClock_m}${color}${font}\n");
			fprintf(fp,"${voffset 12}${alignc}${font Liberation Sans:style=Bold:size=10}${color1}${time %%H:%%M}${color}${font}${voffset -8}\n");
		}
		else
			if (clocktype == 2) {
				fprintf(fp,"${voffset 20}${alignc 44}${font zoraclockH:size=70}${color2}${execpi 120 ~/.conkycolors/bin/conkyClock hour}${color}${font}\n");
				fprintf(fp,"${voffset -90}${alignc 64}${font zoraclockM:size=100}${color2}${execpi 60 ~/.conkycolors/bin/conkyClock minute}${color}${font}\n");
				fprintf(fp,"${voffset 26}${alignc}${font Liberation Sans:style=Bold:size=10}${color1}${time %%H:%%M}${color}${font}${voffset -8}\n");
			}
		else
			if (clocktype == 3) {
				fprintf(fp,"${voffset -12}${goto 28}${font Arial Black:size=38}${color2}${time %%H}${color}${font}${voffset -28}${font Liberation Sans:style=Bold:size=11}${color2}${time :%%M}${time :%%S}${color}${font}\n");
				fprintf(fp,"${voffset -2}${goto 100}${font Liberation Sans:style=Bold:size=8}${color2}${time %%A}${color}${font}\n");
				fprintf(fp,"${goto 100}${time %%d %%b %%Y}\n");
			}
		else
			if (clocktype == 4) {
				fprintf(fp,"${voffset 4}${goto 32}${font clockfaces:size=40}O${font}\n");
				fprintf(fp,"${voffset -34}${goto 41}${font zoraclockH:size=30}${color2}${execpi 120 ~/.conkycolors/bin/conkyClock hour}${color}${font}\n");
				fprintf(fp,"${voffset -39}${goto 35}${font zoraclockM:size=40}${color2}${execpi 60 ~/.conkycolors/bin/conkyClock minute}${color}${font}\n");
				fprintf(fp,"${goto 100}${voffset -38}${font Liberation Sans:style=Bold:size=11}${color2}${time %%H}${time :%%M}${time :%%S}${color}${font}\n");
				fprintf(fp,"${goto 100}${goto 100}${font Liberation Sans:style=Bold:size=8}${color2}${time %%A}${color}${font}\n");
				fprintf(fp,"${goto 100}${time %%d %%b %%Y}${voffset 8}\n");
			}
		else
			if (clocktype == 5);
		else
			fprintf(fp,"${voffset -10}${alignc 46}${color2}${font Arial Black:size=30}${time %%H:%%M}${font}${color}\n");
		if (clocktype != 3 && clocktype != 4) {
			if (clocktype == 1 || clocktype == 2)
				fprintf(fp,"${voffset 8}${alignc}${time %%d %%B %%Y}\n");
			else
				if (clocktype == 5)
					fprintf(fp,"${voffset 4}${alignc}${time %%d %%B %%Y}\n");
				else
					fprintf(fp,"${alignc}${time %%d %%B %%Y}\n");
		}
		if (set_calendar == True) {
			if (m == True)
				fprintf(fp,"${voffset -2}${color0}${font Poky:size=15}d${font}${color}${voffset -8}${font Liberation Mono:size=8}${execpi 10800 DJS=`date +%%-d`; cal -m | sed 's/^/${goto %d} /' | sed '1d' | sed s/\" $DJS \"/\" \"\'${font Liberation Mono:style=bold:size=8}${color1}\'\"$DJS\"\'${color}${font}${font Liberation Mono:size=8}\'\" \"/}${font}${font}${voffset -14}\n", go2);
			else
				fprintf(fp,"${voffset -2}${color0}${font Poky:size=15}d${font}${color}${voffset -8}${font Liberation Mono:size=8}${execpi 10800 DJS=`date +%%-d`; cal | sed 's/^/${goto %d} /' | sed '1d' | sed s/\" $DJS \"/\" \"\'${font Liberation Mono:style=bold:size=8}${color1}\'\"$DJS\"\'${color}${font}${font Liberation Mono:size=8}\'\" \"/}${font}${font}${voffset -14}\n", go2);
		}
	}

	//Photo Widget
	if (set_photo == 1 || set_photo == 2) {
		fprintf(fp,"${voffset 4}${font Liberation Sans:style=Bold:size=8}%s $stippled_hr${font}\n", photo);
		if (set_photo == 1)
			fprintf(fp,"${execi 10800 ~/.conkycolors/bin/conkyPhoto}${image /tmp/conkyPhoto.png -s 175x120 -p 4,%d}${voffset 114}\n",yp);
		else
			fprintf(fp,"${execi 360 ~/.conkycolors/bin/conkyPhotoRandom}${image /tmp/conkyPhoto.png -s 175x120 -p 4,%d}${voffset 114}\n",yp);
	}

	//Rhythmbox Widget
	if (rhythmbox == True) {
		fprintf(fp,"${voffset 4}${font Liberation Sans:style=Bold:size=8}RHYTHMBOX $stippled_hr${font}\n");
		if (cover != 0)
			fprintf(fp,"${execi 10 ~/.conkycolors/bin/conkyCover}${execpi 10 ~/.conkycolors/bin/conkyRhythmbox -t ~/.conkycolors/templates/conkyPlayer.template}\n");
		else
			fprintf(fp,"${execpi 10 ~/.conkycolors/bin/conkyRhythmbox -t ~/.conkycolors/templates/conkyPlayer.template}\n");
	}

	//Banshee Widget
	if (banshee == True) {
		fprintf(fp,"${voffset 4}${font Liberation Sans:style=Bold:size=8}BANSHEE $stippled_hr${font}\n");
		if (cover != 0)
			fprintf(fp,"${execi 10 ~/.conkycolors/bin/conkyCover}${execpi 10 ~/.conkycolors/bin/conkyBanshee -t ~/.conkycolors/templates/conkyPlayer.template}\n");
		else
			fprintf(fp,"${execpi 10 ~/.conkycolors/bin/conkyBanshee -t ~/.conkycolors/templates/conkyPlayer.template}\n");
	}

	//Exaile Widget
	if (exaile == True) {
		fprintf(fp,"${voffset 4}${font Liberation Sans:style=Bold:size=8}EXAILE $stippled_hr${font}\n");
		if (cover != 0)
			fprintf(fp,"${execi 10 ~/.conkycolors/bin/conkyCover}${execpi 10 ~/.conkycolors/bin/conkyExaile -t ~/.conkycolors/templates/conkyPlayer.template}\n");
		else
			fprintf(fp,"${execpi 10 ~/.conkycolors/bin/conkyExaile -t ~/.conkycolors/templates/conkyPlayer.template}\n");
	}

	//MPD Widget
	if (mpd == True) {
		fprintf(fp,"${voffset 4}${font Liberation Sans:style=Bold:size=8}MPD $stippled_hr${font}\n");
		fprintf(fp,"${execpi 10 ~/.conkycolors/bin/conkyMPD}\n");
	}

	//ToDo
	if (todo == True) {
		fprintf(fp,"${voffset 4}${font Liberation Sans:style=Bold:size=8}TO DO $stippled_hr${font}\n");
		fprintf(fp,"${voffset 4}${execpi 20 cat ~/ToDo.txt | sed -n '1,12p' | sed 's/^/${voffset -6}${color0}${font Poky:size=14}A${font}${color}${voffset -3}${goto %d}/'}\n", go2);
	}

	//NVIDIA Widget
	if (nvidia == True) {
		fprintf(fp,"${voffset 4}${font Liberation Sans:style=Bold:size=8}NVIDIA $stippled_hr${font}\n");
		fprintf(fp,"${color0}${voffset -4}${font Poky:size=17}N${font}${color}");
		fprintf(fp,"${goto %d}${voffset -8}GPU Temp:${alignr}${font Liberation Sans:style=Bold:size=8}${color1} ${exec nvidia-settings -q GPUCoreTemp | grep Attribute | cut -d ' ' -f 6 | cut -c 1-2}${font}${color}°C\n", go2);
		fprintf(fp,"${goto %d}GPU Clock:${alignr}${font Liberation Sans:style=Bold:size=8}${color1} ${exec nvidia-settings -q GPU2DClockFreqs -t}${font}${color}MHz\n", go2);
		fprintf(fp,"${goto %d}Video RAM:${alignr}${font Liberation Sans:style=Bold:size=8}${color1} ${exec nvidia-settings -q VideoRam -t}${font}${color}KiB\n", go2);
		fprintf(fp,"${goto %d}Driver Version:${alignr}${font Liberation Sans:style=Bold:size=8}${color1} ${exec nvidia-settings -q NvidiaDriverVersion -t}${font}${color}\n", go2);
	}

	//HD Widget
	if (set_hd == True) {
		fprintf(fp,"${voffset 4}${font Liberation Sans:style=Bold:size=8}%s $stippled_hr${font}\n", hd);
		if (hdtemp1 == True) {
			if (hdtemp2 == True || hdtemp3 == True || hdtemp4 == True)
				if (unit == True)
					fprintf(fp,"  ${voffset 4}${color0}${font Weather:size=15}y${font}${color}${voffset -8}${goto %d}/dev/%s: ${font Liberation Sans:style=Bold:size=8}${color1}${execi 120 hddtemp /dev/%s -n --unit=F}°F${color}${font}\n", go2, dev1, dev1);
				else
					fprintf(fp,"  ${voffset 4}${color0}${font Weather:size=15}y${font}${color}${voffset -8}${goto %d}/dev/%s: ${font Liberation Sans:style=Bold:size=8}${color1}${execi 120 hddtemp /dev/%s -n --unit=C}°C${color}${font}\n", go2, dev1, dev1);
			else
				if (unit == True)
					fprintf(fp,"  ${voffset 4}${color0}${font Weather:size=15}y${font}${color}${voffset -3}${goto %d}%s: ${font Liberation Sans:style=Bold:size=8}${color1}${execi 120 hddtemp /dev/%s -n --unit=F}°F${color}${font}${alignr}${color2}/dev/%s${color}\n", go2, temperature, dev1, dev1);
				else
					fprintf(fp,"  ${voffset 4}${color0}${font Weather:size=15}y${font}${color}${voffset -3}${goto %d}%s: ${font Liberation Sans:style=Bold:size=8}${color1}${execi 120 hddtemp /dev/%s -n --unit=C}°C${color}${font}${alignr}${color2}/dev/%s${color}\n", go2, temperature, dev1, dev1);
		}
		if (hdtemp2 == True) {
			if (unit == True)
				fprintf(fp,"${goto %d}/dev/%s: ${font Liberation Sans:style=Bold:size=8}${color1}${execi 120 hddtemp /dev/%s -n --unit=F}°F${color}${font}\n", go2, dev2, dev2);
			else
				fprintf(fp,"${goto %d}/dev/%s: ${font Liberation Sans:style=Bold:size=8}${color1}${execi 120 hddtemp /dev/%s -n --unit=C}°C${color}${font}\n", go2, dev2, dev2);
		}
		if (hdtemp3 == True) {
			if (unit == True)
				fprintf(fp,"${goto %d}/dev/%s: ${font Liberation Sans:style=Bold:size=8}${color1}${execi 120 hddtemp /dev/%s -n --unit=F}°F${color}${font}\n", go2, dev3, dev3);
			else
				fprintf(fp,"${goto %d}/dev/%s: ${font Liberation Sans:style=Bold:size=8}${color1}${execi 120 hddtemp /dev/%s -n --unit=C}°C${color}${font}\n", go2, dev3, dev3);
		}
		if (hdtemp4 == True) {
			if (unit == True)
				fprintf(fp,"${goto %d}/dev/%s: ${font Liberation Sans:style=Bold:size=8}${color1}${execi 120 hddtemp /dev/%s -n --unit=F}°F${color}${font}\n", go2, dev4, dev4);
			else
				fprintf(fp,"${goto %d}/dev/%s: ${font Liberation Sans:style=Bold:size=8}${color1}${execi 120 hddtemp /dev/%s -n --unit=C}°C${color}${font}\n", go2, dev4, dev4);
		}
		if (hdtype == 1)
			fprintf(fp,"${execpi 30 ~/.conkycolors/bin/conkyHD1}\n");
		else
			if (hdtype == 2)
				fprintf(fp,"${execpi 30 ~/.conkycolors/bin/conkyHD2}\n");
			else
				if (hdtype == 3)
					fprintf(fp,"${execpi 30 ~/.conkycolors/bin/conkyHD3}\n");
			else
				fprintf(fp,"${execpi 30 ~/.conkycolors/bin/conkyHD4}\n");
	}

	//Network Widget
	if (set_network == True) {
		fprintf(fp,"${voffset 4}${font Liberation Sans:style=Bold:size=8}%s $stippled_hr${font}\n", network);
		fprintf(fp,"${if_existing /proc/net/route wlan%d}\n", wlan);
		fprintf(fp,"${voffset -13}${color0}${font VariShapes Solid:size=14}q${font}${color}${goto %d}${voffset -6}%s: ${font Liberation Sans:style=Bold:size=8}${color1}${upspeed wlan%d}${color}${font} ${alignr}${color2}${upspeedgraph wlan%d 8,60 %s}${color}\n", go2, up, wlan, wlan, color3);
		fprintf(fp,"${goto %d}%s: ${color2}${totalup wlan%d}${color}\n", go2, total, wlan);
		fprintf(fp,"${voffset -2}${color0}${font VariShapes Solid:size=14}Q${font}${color}${goto %d}${voffset -6}%s: ${font Liberation Sans:style=Bold:size=8}${color1}${downspeed wlan%d}${color}${font} ${alignr}${color2}${downspeedgraph wlan%d 8,60 %s}${color}\n", go2, down, wlan, wlan, color3);
		fprintf(fp,"${goto %d}%s: ${color2}${totaldown wlan%d}${color}\n", go2, total, wlan);
		fprintf(fp,"${voffset -2}${color0}${font Poky:size=14}Y${font}${color}${goto %d} ${voffset -2}%s: ${font Liberation Sans:style=Bold:size=8}${color1}${wireless_link_qual wlan%d}%%${color}${font} ${alignr}${color2}${wireless_link_bar 8,60 wlan%d}${color}\n", go2, signal, wlan, wlan);
		fprintf(fp,"${voffset 4}${color0}${font Poky:size=13}w${font}${color}${goto %d}${voffset -8}%s: ${alignr}${color2}${addr wlan%d}${color}\n", go2, localip, wlan);
		fprintf(fp,"${goto %d}%s: ${alignr}${color2}${execi 10800 ~/.conkycolors/bin/conkyIp}${color}\n", go2, publicip);
		fprintf(fp,"${else}${if_existing /proc/net/route eth%d}\n", eth);
		fprintf(fp,"${voffset -13}${color0}${font VariShapes Solid:size=14}q${font}${color}${goto %d}${voffset -6}%s: ${font Liberation Sans:style=Bold:size=8}${color1}${upspeed eth%d}${color}${font} ${alignr}${color2}${upspeedgraph eth%d 8,60 %s}${color}\n", go2, up, eth, eth, color3);
		fprintf(fp,"${goto %d}%s: ${color2}${totalup eth%d}${color}\n", go2, total, eth);
		fprintf(fp,"${voffset -2}${color0}${font VariShapes Solid:size=14}Q${font}${color}${goto %d}${voffset -6}%s: ${font Liberation Sans:style=Bold:size=8}${color1}${downspeed eth%d}${color}${font} ${alignr}${color2}${downspeedgraph eth%d 8,60 %s}${color}\n", go2, down, eth, eth, color3);
		fprintf(fp,"${goto %d}%s: ${color2}${totaldown eth%d}${color}\n", go2, total, eth);
		fprintf(fp,"${voffset -2}${color0}${font Poky:size=13}w${font}${color}${goto %d}${voffset -4}%s: ${alignr}${color2}${addr eth%d}${color}\n", go2, localip, eth);
		fprintf(fp,"${goto %d}%s: ${alignr}${color2}${execi 10800 ~/.conkycolors/bin/conkyIp}${color}\n", go2, publicip);
		fprintf(fp,"${endif}${else}${if_existing /proc/net/route ppp%d}\n", ppp);
		fprintf(fp,"${voffset -13}${color0}${font VariShapes Solid:size=14}q${font}${color}${goto %d}${voffset -6}%s: ${font Liberation Sans:style=Bold:size=8}${color1}${upspeed ppp%d}${color}${font} ${alignr}${color2}${upspeedgraph ppp%d 8,60 %s}${color}\n", go2, up, ppp, ppp, color3);
		fprintf(fp,"${goto %d}%s: ${color2}${totalup ppp%d}${color}\n", go2, total, ppp);
		fprintf(fp,"${voffset -2}${color0}${font VariShapes Solid:size=14}Q${font}${color}${goto %d}${voffset -6}%s: ${font Liberation Sans:style=Bold:size=8}${color1}${downspeed ppp%d}${color}${font} ${alignr}${color2}${downspeedgraph ppp%d 8,60 %s}${color}\n", go2, down, ppp, ppp, color3);
		fprintf(fp,"${goto %d}%s: ${color2}${totaldown ppp%d}${color}\n", go2, total, ppp);
		fprintf(fp,"${voffset -2}${color0}${font Poky:size=13}w${font}${color}${goto %d}${voffset -4}%s: ${alignr}${color2}${addr ppp%d}${color}\n", go2, localip, ppp);
		fprintf(fp,"${endif}${else}");
		fprintf(fp,"${voffset 4}${color0}${font PizzaDude Bullets:size=12}4${font}${color}${goto %d}%s${endif}${endif}\n", go2, nonet);
	}

	//Pidgin Widget
	if (pidgin == True) {
		fprintf(fp,"${voffset 4}${font Liberation Sans:style=Bold:size=8}PIDGIN $stippled_hr${font}${if_running pidgin}\n");
		if (gmail == True)
			fprintf(fp,"${voffset -8}${color0}${font Martin Vogel's Symbols:size=19}B${font}${color}${goto %d}Gmail: ${alignr}${font Liberation Sans:style=Bold:size=8}${color0}${execpi 3600 ~/.conkycolors/bin/conkyEmail --servertype=IMAP --servername=imap.googlemail.com -u %s -p %s --ssl}${color}${font} %s email(s)\n", go2, user, password, new);
		fprintf(fp,"${voffset 4}${execpi 10 ~/.conkycolors/bin/conkyPidgin -o -s -l %d}${else}\n", limit);
		fprintf(fp,"${voffset 4}${color0}${font PizzaDude Bullets:size=12}4${font}${color}${goto %d}%s${endif}\n\n", go2,nopidgin);
	}

	//Weather Widget
	if (set_weather == True) {
		if (set_network == True)
			fprintf(fp,"${voffset -8}${font Liberation Sans:style=Bold:size=8}%s $stippled_hr${font}\n", Weather);
		else
			fprintf(fp,"${voffset 4}${font Liberation Sans:style=Bold:size=8}%s $stippled_hr${font}\n", Weather);
		fprintf(fp,"${if_existing /proc/net/route wlan%d}\n", wlan);
		fprintf(fp,"${execpi 10800 ~/.conkycolors/bin/conkyForecast --location=%s%s -t ~/.conkycolors/templates/conkyForecast.template}\n", weather_code, imperial);
		fprintf(fp,"${else}${if_existing /proc/net/route eth%d}\n", eth);
		fprintf(fp,"${execpi 10800 ~/.conkycolors/bin/conkyForecast --location=%s%s -t ~/.conkycolors/templates/conkyForecast.template}\n", weather_code, imperial);
		fprintf(fp,"${endif}${else}${if_existing /proc/net/route ppp%d}\n", ppp);
		fprintf(fp,"${execpi 10800 ~/.conkycolors/bin/conkyForecast --location=%s%s -t ~/.conkycolors/templates/conkyForecast.template}\n", weather_code, imperial);
		fprintf(fp,"${endif}${else}");
		fprintf(fp,"${voffset 4}${color0}${font PizzaDude Bullets:size=12}4${font}${color}${goto %d}%s${endif}${endif}\n", go2,noweather);
	}

	//BBCWeather Widget
	if (bbcweather == True) {
		if (set_network == True)
			fprintf(fp,"${voffset -8}${font Liberation Sans:style=Bold:size=8}%s $stippled_hr${font}\n", Weather);
		else
			fprintf(fp,"${voffset 4}${font Liberation Sans:style=Bold:size=8}%s $stippled_hr${font}\n", Weather);

		if (unit == True) {
			fprintf(fp,"${goto 12}${voffset 4}${color0}${font Weather:size=24}y${font}${color}\n");
			fprintf(fp,"${voffset -29}${goto %d}%s: ${font Liberation Sans:style=Bold:size=8}${color1}${execi 600 curl -s --connect-timeout 30 \"http://newsrss.bbc.co.uk/weather/forecast/%d/ObservationsRSS.xml\" | sed -n '/Temperature/p' | sed -e 's/&#xB0;/ /g' | sed -e 's/&#37;/%%/g' | sed 's/^.*Temperature: [0-9]* C (//' | sed 's/ F.*$//'}°F${color}${font}\n", go2, temperature, bbccode);
			fprintf(fp,"${goto %d}${voffset -2}${color0}${font VariShapes Solid:size=8}q${font}${color}${font Liberation Sans:style=Bold:size=8}${color1}${execi 600 curl -s --connect-timeout 30 \"http://newsrss.bbc.co.uk/weather/forecast/%d/Next3DaysRSS.xml\" | sed -n '/Max Temp/p' | sed '2!d' | sed -e 's/&#xB0;/ /g' | sed -e 's/&#37;/%%/g' | sed 's/^.*Max Temp: [0-9]* C (//' | sed 's/ F.*$//'}°F${color}${font}  ${voffset -2}${color0}${font VariShapes Solid:size=8}Q${font}${color}${voffset -1}${font Liberation Sans:style=Bold:size=8}${color1}${execi 600 curl -s --connect-timeout 30 \"http://newsrss.bbc.co.uk/weather/forecast/%d/Next3DaysRSS.xml\" | sed -n '/Max Temp/p' | sed '2!d' | sed -e 's/&#xB0;/ /g' | sed -e 's/&#37;/%%/g' | sed 's/^.*Min Temp: [0-9]* C (//' | sed 's/ F.*$//'}°F${color}${font}\n", go2, bbccode, bbccode);
			fprintf(fp,"${goto %d}%s: ${font Liberation Sans:style=Bold:size=8}${color1}${execi 600 curl -s --connect-timeout 30 \"http://newsrss.bbc.co.uk/weather/forecast/%d/Next3DaysRSS.xml\" | sed -n '/Max Temp/p' | sed '2!d' | sed -e 's/&#xB0;/ /g' | sed -e 's/&#37;/%%/g' | sed 's/<[^>]*>//g' | sed 's/^.*Humidity: //' | sed 's/%%.*$//'}%%${color}${font}${alignr}${color2}${execbar curl -s --connect-timeout 30 \"http://newsrss.bbc.co.uk/weather/forecast/%d/Next3DaysRSS.xml\" | sed -n '/Max Temp/p' | sed '2!d' | sed -e 's/&#xB0;/ /g' | sed -e 's/&#37;/%%/g' | sed 's/<[^>]*>//g' | sed 's/^.*Humidity: //' | sed 's/%%.*$//'}%%${color}${font}\n", go2, humidity, bbccode, bbccode);
		}
		else {
			fprintf(fp,"${goto 12}${voffset 4}${color0}${font Weather:size=24}y${font}${color}\n");
			fprintf(fp,"${voffset -29}${goto %d}%s: ${font Liberation Sans:style=Bold:size=8}${color1}${execi 600 curl -s --connect-timeout 30 \"http://newsrss.bbc.co.uk/weather/forecast/%d/ObservationsRSS.xml\" | sed -n '/Temperature/p' | sed -e 's/&#xB0;/ /g' | sed -e 's/&#37;/%%/g' | sed 's/^.*Temperature: //' | sed 's/ C.*$//'}°C${color}${font}\n", go2, temperature, bbccode);
			fprintf(fp,"${goto %d}${voffset -2}${color0}${font VariShapes Solid:size=8}q${font}${color}${color2}${execi 600 curl -s --connect-timeout 30 \"http://newsrss.bbc.co.uk/weather/forecast/%d/Next3DaysRSS.xml\" | sed -n '/Max Temp/p' | sed '2!d' | sed -e 's/&#xB0;/ /g' | sed -e 's/&#37;/%%/g' | sed 's/<[^>]*>//g' | sed 's/^.*Max Temp: //' | sed 's/ C.*$//'}°C${color} ${voffset -2}${color0}${font VariShapes Solid:size=8}Q${font}${voffset -1}${color}${color2}${execi 600 curl -s --connect-timeout 30 \"http://newsrss.bbc.co.uk/weather/forecast/%d/Next3DaysRSS.xml\" | sed -n '/Max Temp/p' | sed '2!d' | sed -e 's/&#xB0;/ /g' | sed -e 's/&#37;/%%/g' | sed 's/<[^>]*>//g' | sed 's/^.*Min Temp: //' | sed 's/ C.*$//'}°C${color}\n", go2, bbccode, bbccode);
			fprintf(fp,"${goto %d}%s: ${font Liberation Sans:style=Bold:size=8}${color1}${execi 600 curl -s --connect-timeout 30 \"http://newsrss.bbc.co.uk/weather/forecast/%d/Next3DaysRSS.xml\" | sed -n '/Max Temp/p' | sed '2!d' | sed -e 's/&#xB0;/ /g' | sed -e 's/&#37;/%%/g' | sed 's/<[^>]*>//g' | sed 's/^.*Humidity: //' | sed 's/%%.*$//'}%%${color}${font}${alignr}${color2}${execbar curl -s --connect-timeout 30 \"http://newsrss.bbc.co.uk/weather/forecast/%d/Next3DaysRSS.xml\" | sed -n '/Max Temp/p' | sed '2!d' | sed -e 's/&#xB0;/ /g' | sed -e 's/&#37;/%%/g' | sed 's/<[^>]*>//g' | sed 's/^.*Humidity: //' | sed 's/%%.*$//'}%%${color}${font}\n", go2, humidity, bbccode, bbccode);
		}
	}

	if ((shiki == True || shikidust == True || dust == True) && (clocktype == 1 || clocktype == 2))
		fprintf(fp,"${voffset -75}\n");

	fclose(fp);
}

int main(int argc, char *argv[]) {

	options (argc, argv);

	translation();

	themes();

	coverposition();
	photoposition();

	conkycover();
	conkyforecast();
	conkyplayer();

	conkyrc();

	printf("Congratulations, your conkyrc was createad\n");

	return 0;
}
