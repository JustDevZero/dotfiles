#!/usr/bin/python
#coding: utf-8

# Copyright (C) 2009 Helmuth Saatkamp (helmuthdu)
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

import sys
from optparse import OptionParser

#Options
class CommandLineParser:

	parser = None

	def __init__(self):

		self.parser = OptionParser()
		self.parser.add_option("-l","--lang", dest="lang", default="en", type="string", help=u"Set language: deutsch OR de, english OR en*, estonian OR et, italian OR it, polish OR pl, portuguese OR pt, russian OR ru, spanish OR es")
		self.parser.add_option("-t","--theme", dest="theme", default="gnome-human", type="string", help=u"Set theme color: gnome-brave, gnome-human*, gnome-noble, gnome-wine, gnome-wise, shiki-brave, shiki-human, shiki-noble, shiki-wine, shiki-wise, shiki-dust, dust")
		self.parser.add_option("-d","--dark", dest="dark", action="store_true", default=False, help=u"Set Dark Brightness(Don't work with skiki-colors/shikidust/dust themes)")
		self.parser.add_option("--alldark",dest="alldark", action="store_true", default=False, help=u"Set Dark Brightness to all(Don't work with any theme)")
		self.parser.add_option("--alllight",dest="alllight", action="store_true", default=False, help=u"[default: %default] IMAP folder to check, not applicable for POP mail checks")
		self.parser.add_option("-s","--side", dest="side", default="right", type="string", help=u"Set light Brightness to all(Don't work with any theme)")
		self.parser.add_option("-c","--cpu", dest="cpu", default=1, type="int", help=u"Set number of cpu core")
		self.parser.add_option("--cputemp", dest="cputemp", action="store_true", default=False, help=u"Enable CPU temperature monitor")
		self.parser.add_option("-u","--updates", dest="update", action="store_true", default=False, help=u"Show updates of Debian/Ubuntu")
		self.parser.add_option("-b","--battery", dest="bat", action="store_true", default=False, help=u"Enable battery monitor")
		self.parser.add_option("--powerbattery", dest="powerbattery", action="store_true", default=False, help=u"Enable \"powerbattery\" script mode")
		self.parser.add_option("-p","--proc", dest="proc", default=0, type="int", help=u"Enable top processes monitor and set the number of processes to show [Max = 10]")
		self.parser.add_option("--clock", dest="clocktype", default="off", type="string", help=u"Enable analog clock monitor and set type: digital, analog, slim or modern")
		self.parser.add_option("--calendar", dest="calendar", action="store_true", default=False, help=u"Enable calendar monitor")
		self.parser.add_option("-m","--monday", dest="monday", action="store_true", default=False, help=u"Set monday as first day in the week in calendar")
		self.parser.add_option("--todo", dest="todo", action="store_true", default=False, help=u"Enable ToDo monitor")
		self.parser.add_option("--hd", dest="hds", default="off", type="string", help=u"Enable hd monitor and set type: classic or meerkat")
		self.parser.add_option("--hdtemp", dest="hdtemp", default="off", type="string", help=u"Enable HD temperature monitor [Ex: --hdtemp=sda]")
		self.parser.add_option("--mpd", dest="mpd", action="store_true", default=False, help=u"Enable MPD monitor")
		self.parser.add_option("--rhythmbox", dest="rhythmbox", action="store_true", default=False, help=u"Enable Rhythmbox monitor")
		self.parser.add_option("--banshee", dest="banshee", action="store_true", default=False, help=u"Enable Banshee monitor")
		self.parser.add_option("--pidgin", dest="pidgin", action="store_true", default=False, help=u"Enable Pidgin monitor")
		self.parser.add_option("--limit", dest="limit", default=5, type="int", help=u"Set a limit to the number of buddies displayed [default: 5]")
		self.parser.add_option("--gmail", dest="gmail", action="store_true", default=False, help=u"Enable gmail monitor in pidgin")
		self.parser.add_option("--user", dest="user", default="<user>", type="string", help=u"Type your login in gmail")
		self.parser.add_option("--password", dest="password", default="<password>", type="string", help=u"Type your password in gmail")
		self.parser.add_option("-n","--network", dest="net", action="store_true", default=False, help=u"Enable network monitor")
		self.parser.add_option("--eth", dest="eth", default=0, type="int", help=u"Change ethernet device [Default=0]")
		self.parser.add_option("--wlan", dest="wlan", default=0, type="int", help=u"Change wireless device [Default=0]")
		self.parser.add_option("--ppp", dest="ppp", default=0, type="int", help=u"Change 3G-Modem device [Default=0]")
		self.parser.add_option("--weather", dest="weather", default="off", type="string", help=u"Enable weather monitor and set your AreaID[Ex: --weather=BRXX0043]")
		self.parser.add_option("--weatherplus", dest="weatherplus", action="store_true", default=False, help=u"Give a plus to the weather monitor")
		self.parser.add_option("-f","--fahrenheit", dest="unit", action="store_true", default=False, help=u"Force output temperature either in Celius or Fahrenheit")
		self.parser.add_option("--logo", dest="logo", default='u', type="string", help=u"Choose your Distro Logo: ubuntu*, fedora, arch, opensuse, pardus, debian, gentoo, xfce, gnome")

	def parse_args(self):
		(options, args) = self.parser.parse_args()
		return (options, args)

	def print_help(self):
		return self.parser.print_help()

class ConkyData:
	def __init__(self,status,coverart,title,album,length,artist,tracknumber,genre,year,filename,current_position_percent,current_position,rating,volume):
		


#Themes
def themes (theme, alldark, alllight):
	if theme == "gnome-brave": 
		color1 = "3465A4"
		if alldark == True:
			color3 = "1E1C1A 1E1C1A"
		elif alllight == True:
			color3 = "white white"
		else:
			color3 = "3465A4 729FCF"
	elif theme == "gnome-dust":
		color1 = "906E4C"
		if alldark == True:
			color3 = "1E1C1A 1E1C1A"
		elif alllight == True:
			color3 = "white white"
		else:
			color3 = "906E4C B49372"
	elif theme == "gnome-illustrious":
		color1 = "dc6472"
		if alldark == True:
			color3 = "1E1C1A 1E1C1A"
		elif alllight == True:
			color3 = "white white"
		else:
			color3 = "dc6472 f2939f"
	elif theme == "gnome-noble":
		color1 = "77507b"
		if alldark == True:
			color3 = "1E1C1A 1E1C1A"
		elif alllight == True:
			color3 = "white white"
		else:
			color3 = "77507b ad7fa8"
	elif theme == "gnome-wine":
		color1 = "C22F2F"
		if alldark == True:
			color3 = "1E1C1A 1E1C1A"
		elif alllight == True:
			color3 = "white white"
		else:
			color3 = "C22F2F DA3F3F"
	elif theme == "gnome-wise":
		color1 = "789E2D"
		if alldark == True:
			color3 = "1E1C1A 1E1C1A"
		elif alllight == True:
			color3 = "white white"
		else:
			color3 = "789E2D A7CC5C"
	elif theme == "shiki-brave":
		color0 = "E6E6E6"
		color1 = "3465A4"
		color2 = "E6E6E6"
		color3 = "3465A4 729FCF"
		shiki = True
	elif theme == "shiki-dust":
		color0 = "E6E6E6"
		color1 = "906E4C"
		color2 = "E6E6E6"
		color3 = "906E4C B49372"
		shikidust = True
	elif theme == "shiki-human":
		color0 = "E6E6E6"
		color1 = "E07A1F"
		color2 = "E6E6E6"
		color3 = "E07A1F FAA546"
		shiki = True
	elif theme == "shiki-illustrious":
		color0 = "E6E6E6"
		color1 = "dc6472"
		color2 = "E6E6E6"
		color3 = "dc6472 f2939f"
		shiki = True
	elif theme == "shiki-noble":
		color0 = "E6E6E6"
		color1 = "77507b"
		color2 = "E6E6E6"
		color3 = "77507b ad7fa8"
		shiki = True
	elif theme == "shiki-wine":
		color0 = "E6E6E6"
		color1 = "C22F2F"
		color2 = "E6E6E6"
		color3 = "C22F2F DA3F3F"
		shiki = True
	elif theme == "shiki-wise":
		color0 = "E6E6E6"
		color1 = "789E2D"
		color2 = "E6E6E6"
		color3 = "789E2D A7CC5C"
		shiki = True
	elif theme == "dust":
		color0 = "996B5C"
		color1 = "996B5C"
		color2 = "E6E6E6"
		color3 = "996B5C 996B5C"
		dust = True
	else: 
		color1 = "E07A1F"
		if alldark == True:
			color3 = "1E1C1A 1E1C1A"
		elif alllight == True:
			color3 = "white white"
		else:
			color3 = "E07A1F FAA546"

#Languages
def languages (language):
	if language == ("pt" or "portuguese"):
		sys = "SISTEMA"
		battery = "Bateria"
		uptime = "Atividade"
		processes = "Processos"
		packages = "Pacotes"
		date = "DATA"
		hd = "HD"
		temperature = "Temperatura"
		updates = "Atualizações"
		new = "Novo(s"
		network = "REDE"
		up = "Up"
		down = "Down"
		upload = "Upload"
		download = "Download"
		signal = "Sinal"
		localip = "Ip local"
		publicip = "Ip externo"
		nonet = "Rede indisponível"
		Weather = "TEMPO"
		noweather = "Tempo indisponível"
		status = "Status"
		song = "Música"
		time = "Tempo"
		nopidgin = "Pidgin não está rodando"
		norhythmbox = "Rhythmbox não está rodando"

	elif language == ("it" or "italian"):
		sys = "SISTEMA"
		battery = "Batteria"
		uptime = "Ligado"
		processes = "Processi"
		packages = "Pacchetti"
		date = "DATA"
		hd = "HD"
		temperature = "Temperatura"
		updates = "Updates"
		new = "New"
		network = "REDE"
		up = "Up"
		down = "Down"
		upload = "Upload"
		download = "Download"
		signal = "Sinal"
		localip = "Ip Locale"
		publicip = "Ip Pubblico"
		nonet = "Rete Non Disponibile"
		Weather = "METEO"
		noweather = "Meteo Non Disponibile"
		status = "Status"
		song = "Song"
		time = "Time"
		nopidgin = "Pidgin non è in esecuzione"
		norhythmbox = "Rhythmbox non è in esecuzione"

	elif language == ("es" or "spanish"):
		sys = "SISTEMA"
		battery = "Batería"
		uptime = "Actividad"
		processes = "Procesos"
		packages = "Paquetes"
		date = "FECHA"
		hd = "HD"
		temperature = "Temperatura"
		updates = "Actualizaciones"
		new = "Nuevo(s"
		network = "RED"
		up = "Envío"
		down = "Recibo"
		upload = "Enviado"
		download = "Recibido"
		signal = "Señal"
		localip = "Ip Local"
		publicip = "Ip Pública"
		nonet = "Red no disponible"
		Weather = "CLIMA"
		noweather = "Clima no disponible"
		status = "Situación"
		song = "Canción"
		time = "Tiempo"
		nopidgin = "Pidgin no esta corriendo"
		norhythmbox = "Rhythmbox no esta corriendo"

	elif language == ("de" or "deutsch"):
		sys = "SISTEMA"
		battery = "Batterie"
		uptime = "Uptime"
		processes = "Prozesse"
		packages = "Pakete"
		date = "DATUM"
		hd = "HD"
		temperature = "Temperatur"
		updates = "Updates"
		new = "New"
		network = "NETZWERK"
		up = "Up"
		down = "Down"
		upload = "Upload"
		download = "Download"
		signal = "Signal"
		localip = "Lokale ip"
		publicip = "Öffentliche ip"
		nonet = "Netzwerk nicht verfügbar"
		Weather = "WETTER"
		noweather = "Wetter nicht verfügbar"
		status = "Status"
		song = "Gesang"
		time = "Zeit"
		nopidgin = "Pidgin nicht läuft"
		norhythmbox = "Rhythmbox nicht läuft"

	elif language == ("pl" or "polish"):
		sys = "SYSTEM"
		battery = "Bateria"
		uptime = "Uruchomiony"
		processes = "Procesów"
		packages = "Pakiety"
		date = "DATA"
		hd = "DYSKI"
		temperature = "Temperatura"
		updates = "Aktualizacje"
		new = "Nowe"
		network = "SIEĆ"
		up = "Wys."
		down = "Pob."
		upload = "Wysłano"
		download = "Pobrano"
		signal = "Sygnał"
		localip = "Lokalne ip"
		publicip = "Publiczne ip"
		nonet = "Sieć Niedostępna"
		Weather = "POGODA"
		noweather = "Pogoda niedostępna"
		status = "Stan"
		song = "Utwór"
		time = "Pozycja"
		nopidgin = "Pidgin nie działa"
		norhythmbox = "Rhythmbox nie działa"

	elif language == ("et" or "estonian"):
		sys = "SÜSTEEM"
		battery = "Aku"
		uptime = "Tööaeg"
		processes = "Protsessid"
		packages = "Pakendid"
		date = "KUUPÄEV"
		hd = "KÕVAKETAS"
		temperature = "Temperatuur"
		updates = "Uuendused"
		new = "uut"
		network = "VÕRK"
		up = "Üles"
		down = "Alla"
		upload = "Üleslaetud"
		download = "Allalaetud"
		signal = "Signaal"
		localip = "Kohalik ip"
		publicip = "Avalik ip"
		nonet = "Võrk pole saadaval"
		Weather = "ILM"
		noweather = "Ilm pole saadaval"
		status = "Staatus"
		song = "Laul"
		time = "Aeg"
		nopidgin = "Pidgin ei tööta"
		norhythmbox = "Rhythmbox ei tööta"

	elif language == ("ru" or "russian"):
		sys = "СИСТЕМА"
		battery = "Батарея"
		uptime = "Время работы"
		processes = "Процессы"
		packages = "Пакеты"
		date = "ДАТА"
		hd = "ДИСКИ"
		temperature = "Температура"
		updates = "Обновления"
		new = "Новое"
		network = "СЕТЬ"
		up = "Отправка"
		down = "Приём"
		upload = "Всего отправлено"
		download = "Всего получено"
		signal = "Сигнал"
		localip = "Локальный IP"
		publicip = "Внешний IP"
		nonet = "Сеть недоступна"
		Weather = "ПОГОДА"
		noweather = "Информация о погоде недоступна"
		status = "Статус"
		song = "Композиция"
		time = "Время"
		nopidgin = "Pidgin не запущен"
		norhythmbox = "Rhythmbox не запущен"

	else:
		sys = "SYSTEM"
		battery = "Battery"
		uptime = "Uptime"
		processes = "Processes"
		packages = "Packages"
		date = "DATE"
		hd = "HD"
		temperature = "Temperature"
		updates = "Updates"
		new = "New"
		network = "NETWORK"
		up = "Up"
		down = "Down"
		upload = "Upload"
		download = "Download"
		signal = "Signal"
		localip = "Local ip"
		publicip = "Public ip"
		nonet = "Network Unavailable"
		Weather = "WEATHER"
		noweather = "Weather Unavailable"
		status = "Status"
		song = "Song"
		time = "Time"
		nopidgin = "Pidgin not running"
		norhythmbox = "Rhythmbox not running"

#Create and write conkyForecast.template
def conkyForecast (unit, weatherplus):
	arq = open (conkyForecast.template, 'w')

	arq.write("${voffset -10}${alignr 56}${color2}${font ConkyWeather:style=Bold:size=40}[--datatype=WF]${font}${color}\n")
	if unit == True:
		arq.write("${voffset -50}${color2}${font Weather:size=40}y${font}${color2}  ${voffset -38}${color2}${font Arial Black:size=26}[--datatype=HT --imperial]${font}${color}\n")
	else:
		arq.write("${voffset -50}${color2}${font Weather:size=40}y${font}${color2}  ${voffset -38}${color2}${font Arial Black:size=26}[--datatype=HT]${font}${color}\n")
	arq.write("${voffset 2}\n")
	if (shiki == True or shikidust == True or dust == True):
		arq.write("${voffset 0}${goto 16}[--datatype=DW --startday=1 --shortweekday] ${goto 66}[--datatype=DW --startday=2 --shortweekday] ${goto 112}[--datatype=DW --startday=3 --shortweekday] ${goto 156}[--datatype=DW --startday=4 --shortweekday]\n")
	else:
		arq.write("${voffset 0}${goto 13}[--datatype=DW --startday=1 --shortweekday] ${goto 61}[--datatype=DW --startday=2 --shortweekday] ${goto 105}[--datatype=DW --startday=3 --shortweekday] ${goto 150}[--datatype=DW --startday=4 --shortweekday]\n")
	arq.write("${voffset 0}${color2}${font ConkyWeather:size=28}[--datatype=WF --startday=1 --endday=4 --spaces=1]${font}${color}\n")
	if unit == True:
		arq.write("${voffset 0}${alignr 33}[--imperial --datatype=HT --startday=1 --hideunits --centeredwidth=3]/[--imperial --datatype=LT --startday=1 --hideunits --centeredwidth=3] ${alignr 24}[--imperial --datatype=HT --startday=2 --hideunits --centeredwidth=3]/[--imperial --datatype=LT --startday=2 --hideunits --centeredwidth=3] ${alignr 16}[--imperial --datatype=HT --startday=3 --hideunits --centeredwidth=3]/[--imperial --datatype=LT --startday=3 --hideunits --centeredwidth=3] ${alignr 10}[--imperial --datatype=HT --startday=4 --hideunits --centeredwidth=3]/[--imperial --datatype=LT --startday=4 --hideunits --centeredwidth=3]\n")
	else:
		arq.write("${voffset 0}${alignr 33}[--datatype=HT --startday=1 --hideunits --centeredwidth=3]/[--datatype=LT --startday=1 --hideunits --centeredwidth=3] ${alignr 24}[--datatype=HT --startday=2 --hideunits --centeredwidth=3]/[--datatype=LT --startday=2 --hideunits --centeredwidth=3] ${alignr 16}[--datatype=HT --startday=3 --hideunits --centeredwidth=3]/[--datatype=LT --startday=3 --hideunits --centeredwidth=3] ${alignr 10}[--datatype=HT --startday=4 --hideunits --centeredwidth=3]/[--datatype=LT --startday=4 --hideunits --centeredwidth=3]\n")
	if weatherplus == True:
		arq.write("${voffset 5}${goto 12}${font Moon Phases:style=Bold:size=36}${color2}[--datatype=MF]${color}${font}\n")
		arq.write("${voffset 2}${goto 10}${font ConkyWindNESW:size=40}${color2}[--datatype=BS]${color}${font}\n")
		if unit == True:
			arq.write("${voffset 5}${goto 22}[--datatype=WS --imperial]\n${goto 22}[--datatype=WD]\n")
		else:
			arq.write("${voffset 5}${goto 22}[--datatype=WS]\n${goto 22}[--datatype=WD]\n")
		arq.write("${voffset -122}${goto 75}${font Liberation Sans Mono:style=Bold:size=8}${color2}[--datatype=CT]${color}${font}\n")
		arq.write("${voffset 6}${goto 75}Station: [--datatype=OB]\n")
		arq.write("${goto 75}Rain: [--datatype=PC]\n")
		arq.write("${goto 75}UV: [--datatype=UI] - [--datatype=UT]\n")
		arq.write("${goto 75}Humidity: [--datatype=HM]\n")
		arq.write("${goto 75}Dew Point: [--datatype=DP]\n")
		arq.write("${goto 75}Sunrise: [--datatype=SR]\n")
		arq.write("${goto 75}Sunset: [--datatype=SS]\n")
		arq.write("${goto 75}Moon: [--datatype=MP]\n")
		arq.write("${voffset -100}")
	else:
		arq.write("${voffset -10}")

	arq.close ()

def conkyrc():

		#Create and write .conkyrc
		arq = open (conkyrc, 'w')

		#Global Setup
		arq.write("use_xft yes\n")
		arq.write("xftfont Liberation Sans:size=8\n")
		arq.write("\n")
		arq.write("update_interval 1\n")
		arq.write("total_run_times 0\n")
		arq.write("double_buffer yes\n")
		arq.write("text_buffer_size 2048\n")
		arq.write("\n")
		arq.write("own_window yes\n")
		if shiki == True:
			arq.write("own_window_colour 3C3C3C\n")
		elif shikidust == True:
			arq.write("own_window_colour 464139\n")
		elif dust == True:
			arq.write("own_window_colour 2C2B29\n")
		arq.write("own_window_type override\n")
		if (shiki == True or shikidust == True or dust == True):
			arq.write("own_window_transparent no\n")
		else:
			arq.write("own_window_transparent yes\n")
		arq.write("own_window_hints undecorated,below,sticky,skip_taskbar,skip_pager\n")
		arq.write("\n")
		arq.write("minimum_size 185 0\n")
		arq.write("maximum_width 185\n")
		arq.write("\n")
		if (shiki == True or shikidust == True or dust == True):
			if shikidust == True:
				arq.write("default_color D1CCC4\n")
			elif dust == True:
				arq.write("default_color 929292\n")
			else:
				arq.write("default_color D8D8D8\n")
			arq.write("draw_borders yes\n")
			arq.write("border_margin 10\n")
			arq.write("draw_graph_borders yes\n")
			arq.write("draw_outline no\n")
		elif(dark == True or alldark == True):
				arq.write("default_color 1E1C1A\n")
		else:
			arq.write("default_color white\n")
		arq.write("draw_shades no\n")
		arq.write("\n")
		if (shiki == True or shikidust == True or dust == True):
			arq.write("color0 %s\n", color0)
		elif (dark == True or alldark == True):
			arq.write("color0 1E1C1A\n")
		else:
			arq.write("color0 white\n")
		if alldark == True:
			arq.write("color1 1E1C1A\n")
		elif alllight == True:
			arq.write("color1 white\n")
		else:
			arq.write("color1 %s\n", color1)
		if (shiki == True or shikidust == True or dust == True):
			arq.write("color2 %s\n", color2)
		elif (dark == True or alldark == True):
			arq.write("color2 1E1C1A\n")
		else:
			arq.write("color2 white\n")
		arq.write("\n")
		if side == "left":
			arq.write("alignment top_left\n")
		else:
			arq.write("alignment top_right\n")
		arq.write("gap_x 25\n")
		arq.write("gap_y 50\n")
		arq.write("\n")
		arq.write("no_buffers no\n")
		arq.write("net_avg_samples 2\n")
		arq.write("\n")
		arq.write("override_utf8_locale yes\n")
		arq.write("\n")
		arq.write("no_buffers yes\n")
		arq.write("\n")
		arq.write("TEXT\n")

		#System Monitor
		arq.write("%s $stippled_hr\n", sys)
		arq.write("${voffset 2}${color0}${font OpenLogos:size=16}%s${font}${color}   Kernel:  ${alignr}${color2}${kernel}${color}\n", set_logo)
		for i in range(1,cpu+1):
			if cputemp == True:
				if unit == "F":
					arq.write("${color0}${font StyleBats:size=16}A${font}${color}   CPU%d: ${font Liberation Sans:style=Bold:size=8}${color1}${cpu cpu%d}%%${font} ${alignr}${voffset -2}${color0}${font Weather:size=14}y${font}${color} ${voffset -3}${font Liberation Sans:style=Bold:size=8}${color1}${execi 30 sensors -f | grep 'Core%d Temp' | cut -c14-16}°F${color}${font}  ${color2}${cpubar cpu%d 8,50}${color}\n", i, i, i-1, i)
				else:
					arq.write("${color0}${font StyleBats:size=16}A${font}${color}   CPU%d: ${font Liberation Sans:style=Bold:size=8}${color1}${cpu cpu%d}%%${font} ${alignr}${voffset -2}${color0}${font Weather:size=14}y${font}${color} ${voffset -3}${font Liberation Sans:style=Bold:size=8}${color1}${execi 30 sensors | grep 'Core%d Temp' | cut -c15-16}°C${color}${font}  ${color2}${cpubar cpu%d 8,50}${color}\n", i, i, i-1, i)
			else:
				arq.write("${color0}${font StyleBats:size=16}A${font}${color}   CPU%d: ${font Liberation Sans:style=Bold:size=8}${color1}${cpu cpu%d}%%${color}${font} ${alignr}${color2}${cpubar cpu%d 8,60}${color}\n", i, i, i)
		arq.write("${color0}${font StyleBats:size=16}g${font}${color}   RAM: ${font Liberation Sans:style=Bold:size=8}${color1}$memperc%%${color}${font} ${alignr}${color2}${membar 8,60}${color}\n")
		arq.write("${color0}${font StyleBats:size=16}j${font}${color}   SWAP: ${font Liberation Sans:style=Bold:size=8}${color1}$swapperc%%${color}${font} ${alignr}${color2}${swapbar 8,60}${color}\n")
		if bat == True:
			if powerbattery == True:
				arq.write("${font Webdings:size=16}~${font}${color}  %s: ${color2}${execpi 60 ~/.scripts/powerbattery.py}${color}\n", battery)
			else:
				arq.write("${font Webdings:size=16}~${font}${color}  %s: ${font Liberation Sans:style=Bold:size=8}${color1}${battery_percent BAT0}%%${color}${font} ${alignr}${color2}${battery_bar 8,60 BAT0}${color}\n", battery)
		arq.write("${color0}${font StyleBats:size=16}q${font}${color}   %s: ${alignr}${color2}${uptime}${color}\n", uptime)
		if update == True:
			arq.write("${color0}${font Webdings:size=15}i${font}${color}  %s: ${alignr}${font Liberation Sans:style=Bold:size=8}${color1}${execi 10800 aptitude search \"~U\" | wc -l | tail}${color}${font} ${color2}%s${color}\n", updates, packages)
		if proc > 0:
			arq.write("${color0}${font StyleBats:size=16}l${font}${color}   %s: ${color2}${alignr 13}CPU${alignr}RAM${color}\n", processes)
			for i in range (1,proc+1):
				arq.write("${goto 32}${top name %d}${font Liberation Sans:style=Bold:size=8}${color1} ${goto 124}${top cpu %d}${alignr }${top mem %d}${color}${font}\n", i, i, i)
		arq.write("\n")

		#Clock and Calendar Monitor
		if clock == "off" and calendar == "false":
			arq.write("%s $stippled_hr\n", date)
			if clock == "analog":
				arq.write("${voffset 10}${alignc 55}${font aClock:style=_Hour:size=90}${color2}${execi 120 python ~/.scripts/conkyClock_h.py}${color}${font}\n")
				arq.write("${voffset -98}${alignc 55}${font aClock:style=_Min:size=90}${color2}${execi 60 python ~/.scripts/conkyClock_m.py}${color}${font}\n")
				arq.write("${voffset 12}${alignc}${font Liberation Sans:style=Bold:size=10}${color1}${time %%H:%%M}${color}${font}${voffset -8}\n")
			elif clock == "slim":
				arq.write("${voffset 20}${alignc 44}${font zoraclockH:size=70}${color2}${execpi 20 ~/.scripts/clock.sh hour}${color}${font}\n")
				arq.write("${voffset -90}${alignc 64}${font zoraclockM:size=100}${color2}${execpi 20 ~/.scripts/clock.sh minute}${color}${font}\n")
				arq.write("${voffset 26}${alignc}${font Liberation Sans:style=Bold:size=10}${color1}${time %%H:%%M}${color}${font}${voffset -8}\n")
			elif clock == "modern":
				arq.write("${voffset -6}${goto 28}${font Arial Black:size=38}${color2}${time %%H}${color}${font}${voffset -28}${font Liberation Sans:style=Bold:size=11}${color2}${time :%%M}${time :%%S}${color}${font}\n")
				arq.write("${voffset -3}${goto 100}${font Liberation Sans:style=Bold:size=8}${color2}${time %%A}${color}${font}\n")
				arq.write("${voffset -1}${goto 100}${time %%d %%B %%Y}\n")
			elif clock == "digital":
				arq.write("${alignc 45}${color2}${font Arial Black:size=30}${time %%H:%%M}${font}${color}\n")
			if calendar == True:
				if m == True:
					arq.write("${voffset 4}${color0}${font RsbillsDng:size=20}O${font}${color}${voffset -4}${font Liberation Mono:size=8}${execpi 10800 DJS=`date +%%_d`; cal -m | sed 's/^/${alignc} /' | sed s/\" $DJS \"/\" \"\'${font Liberation Mono:style=bold:size=8}${color1}\'\"$DJS\"\'${color}${font}${font Liberation Mono:size=8}\'\" \"/}${font}${font}\n")
				else:
					arq.write("${voffset 4}${color0}${font RsbillsDng:size=20}O${font}${color}${voffset -4}${font Liberation Mono:size=8}${execpi 10800 DJS=`date +%%_d`; cal | sed 's/^/${alignc} /' | sed s/\" $DJS \"/\" \"\'${font Liberation Mono:style=bold:size=8}${color1}\'\"$DJS\"\'${color}${font}${font Liberation Mono:size=8}\'\" \"/}${font}${font}\n")
			elif clock == "digital":
				arq.write("${alignc}${time %%A %%d %%Y}\n")
			elif clock == ("analog" or "slim"):
				arq.write("${voffset 8}${alignc}${time %%A %%d %%Y}\n")
			if clock == "modern" and calendar == False:
				arq.write("\n")

		#ToDo
		if todo == True:
			arq.write("TO DO $stippled_hr\n")
			arq.write("${execpi 20 cat ~/ToDo.txt | sed -n '1,12p' | sed 's/^/${voffset 2}${color0}${font RsbillsDng:size=18}d${font}${color}${voffset -5}   /'}\n")
			arq.write("\n")

		#HD Monitor
		if hds != "off":
			arq.write("%s $stippled_hr\n", hd)
			if hdtemp != "off":
				if unit == "F":
					arq.write("  ${voffset 4}${color0}${font Weather:size=15}y${font}${color}${voffset -2}     %s: ${font Liberation Sans:style=Bold:size=8}${color1}${execi 120 hddtemp /dev/%s -n --unit=F}°F${color}${font}${alignr}${color2}/dev/%s${color}\n", temperature, dev, dev)
				else:
					arq.write("  ${voffset 4}${color0}${font Weather:size=15}y${font}${color}${voffset -2}     %s: ${font Liberation Sans:style=Bold:size=8}${color1}${execi 120 hddtemp /dev/%s -n --unit=C}°C${color}${font}${alignr}${color2}/dev/%s${color}\n", temperature, dev, dev)
			if hds == "meerkat":
				arq.write("${execpi 30 ~/.scripts/hd_meerkat.py}\n")
			else:
				arq.write("${execpi 30 ~/.scripts/hd_default.py}\n")
		arq.write("\n")

		#Network Monitor
		if net == True:
			arq.write("%s $stippled_hr\n", network)
			arq.write("${if_existing /proc/net/route wlan%d}\n", wlan)
			arq.write("${voffset -6}${color0}${font PizzaDude Bullets:size=14}O${font}${color}   %s: ${font Liberation Sans:style=Bold:size=8}${color1}${upspeed wlan%d}${color}${font} kb/s ${alignr}${upspeedgraph wlan%d 8,60 %s}\n", up, wlan, wlan, color3)
			arq.write("${voffset 4}${color0}${font PizzaDude Bullets:size=14}U${font}${color}   %s: ${font Liberation Sans:style=Bold:size=8}${color1}${downspeed wlan%d}${color}${font} kb/s ${alignr}${downspeedgraph wlan%d 8,60 %s}\n", down, wlan, wlan, color3)
			arq.write("${voffset 4}${color0}${font PizzaDude Bullets:size=14}N${font}${color}   %s: ${alignr}${totalup wlan%d}\n", upload, wlan)
			arq.write("${voffset 4}${color0}${font PizzaDude Bullets:size=14}T${font}${color}   %s: ${alignr}${totaldown wlan%d}\n", download, wlan)
			arq.write("${voffset 4}${color0}${font PizzaDude Bullets:size=14}Z${font}${color}   %s: ${font Liberation Sans:style=Bold:size=8}${color1}${wireless_link_qual wlan%d}%%${color}${font} ${alignr}${color2}${wireless_link_bar 8,60 wlan%d}${color}\n", signal, wlan, wlan)
			arq.write("${voffset 4}${color0}${font PizzaDude Bullets:size=14}a${font}${color}   %s: ${alignr}${color2}${addr wlan%d}${color}\n", localip, wlan)
			arq.write("${voffset 4}${color0}${font PizzaDude Bullets:size=14}b${font}${color}   %s: ${alignr}${color2}${execi 10800 ~/.scripts/ip.sh}${color}\n", publicip)
			arq.write("${else}${if_existing /proc/net/route eth%d}\n", eth)
			arq.write("${voffset -6}${color0}${font PizzaDude Bullets:size=14}O${font}${color}   %s: ${font Liberation Sans:style=Bold:size=8}${color1}${upspeed eth%d}${color}${font} kb/s ${alignr}${upspeedgraph eth%d 8,60 %s}\n", up, eth, eth, color3)
			arq.write("${voffset 4}${color0}${font PizzaDude Bullets:size=14}U${font}${color}   %s: ${font Liberation Sans:style=Bold:size=8}${color1}${downspeed eth%d}${color}${font} kb/s ${alignr}${downspeedgraph eth%d 8,60 %s}\n", down, eth, eth, color3)
			arq.write("${voffset 4}${color0}${font PizzaDude Bullets:size=14}N${font}${color}   %s: ${alignr}${color2}${totalup eth%d}${color}\n", upload, eth)
			arq.write("${voffset 4}${color0}${font PizzaDude Bullets:size=14}T${font}${color}   %s: ${alignr}${color2}${totaldown eth%d}${color}\n", download, eth)
			arq.write("${voffset 4}${color0}${font PizzaDude Bullets:size=14}a${font}${color}   %s: ${alignr}${color2}${addr eth%d}${color}\n", localip, eth)
			arq.write("${voffset 4}${color0}${font PizzaDude Bullets:size=14}b${font}${color}   %s: ${alignr}${color2}${execi 10800 ~/.scripts/ip.sh}${color}\n", publicip)
			arq.write("${endif}${else}${if_existing /proc/net/route ppp%d}\n", ppp)
			arq.write("${voffset -6}${color0}${font PizzaDude Bullets:size=14}O${font}${color}   %s: ${font Liberation Sans:style=Bold:size=8}${color1}${upspeed ppp%d}${color}${font} kb/s ${alignr}${upspeedgraph ppp%d 8,60 %s}\n", up, ppp, ppp, color3)
			arq.write("${voffset 4}${color0}${font PizzaDude Bullets:size=14}U${font}${color}   %s: ${font Liberation Sans:style=Bold:size=8}${color1}${downspeed ppp%d}${color}${font} kb/s ${alignr}${downspeedgraph ppp%d 8,60 %s}\n", down, ppp, ppp, color3)
			arq.write("${voffset 4}${color0}${font PizzaDude Bullets:size=14}N${font}${color}   %s: ${alignr}${color2}${totalup ppp%d}${color}\n", upload, ppp)
			arq.write("${voffset 4}${color0}${font PizzaDude Bullets:size=14}T${font}${color}   %s: ${alignr}${color2}${totaldown ppp%d}${color}\n", download, ppp)
			arq.write("${voffset 4}${color0}${font PizzaDude Bullets:size=14}a${font}${color}   %s: ${alignr}${color2}${addr ppp%d}${color}\n", localip, ppp)
			arq.write("${endif}${else}")
			arq.write("${voffset 4}${color0}${font PizzaDude Bullets:size=12}4${font}${color}   %s\n", nonet)
			arq.write("${endif}\n")

		#Pidgin Monitor
		if pidgin == True:
			arq.write("PIDGIN $stippled_hr${if_running pidgin}\n")
			if gmail == True:
				arq.write("${voffset -8}${color0}${font Martin Vogel's Symbols:size=19}B${font}${color}  Gmail: ${alignr}${font Liberation Sans:style=Bold:size=8}${color0}${execpi 3600 ~/.scripts/conkyEmail.py --servertype=IMAP --servername=imap.googlemail.com -u %s -p %s --ssl}${color}${font} %s email(s)\n", user, password, new)
			arq.write("${voffset 4}${execpi 10 ~/.scripts/conkyPidgin.py -o -s -l %d}${else}\n", limit)
			arq.write("${voffset 4}${color0}${font PizzaDude Bullets:size=12}4${font}${color}   %s${endif}\n\n",nopidgin)

		#MPD Monitor
		if mpd == True:
			arq.write("MPD $stippled_hr\n")
			arq.write("${voffset 4}${color0}${font Webdings:size=14}U${font}${color}   Status: $alignr$mpd_status\n")
			arq.write("${execpi 10 ~/.scripts/mpd.awk}\n")

		#Rhythmbox Monitor
		if rhythmbox == True:
			arq.write("RHYTHMBOX $stippled_hr${if_running rhythmbox}\n")
			arq.write("${voffset 2}${color0}${font Webdings:size=16}U${font}${color}   %s:${alignr}${color2}${execpi 10 ~/.scripts/conkyRhythmbox.py --datatype=ST}${color}\n", status)
			arq.write("${voffset 2}${color0}${font Musicelements:size=16}z${font}${color}     %s:${alignr}${color2}${execpi 10 ~/.scripts/conkyRhythmbox.py --datatype=AR}${color}\n", song)
			arq.write("${color2}${alignr}${execpi 10 ~/.scripts/conkyRhythmbox.py --datatype=AL}${color}\n")
			arq.write("${color2}${alignr}${execpi 10 ~/.scripts/conkyRhythmbox.py --datatype=TI}${color}\n")
			arq.write("${voffset -4}${color0}${font Martin Vogel's Symbols:size=17}U${font}${color}    %s:${alignr}${color2}${execpi 10 ~/.scripts/conkyRhythmbox.py --datatype=PT}/${execp ~/.scripts/conkyRhythmbox.py --datatype=LE}${color}${else}\n", time)
			arq.write("${voffset 4}${color0}${font PizzaDude Bullets:size=12}4${font}${color}   %s${endif}\n\n",norhythmbox)

		#Banshee Monitor
		if banshee == True:
			arq.write("BANSHEE $stippled_hr\n")
			arq.write("${voffset 2}${color0}${font Webdings:size=16}U${font}${color}   %s:${alignr}${color2}${execpi 10 ~/.scripts/conkyBanshee.py --status}${color}\n", status)
			arq.write("${voffset 2}${color0}${font Musicelements:size=16}z${font}${color}     %s:${alignr}${color2}${execpi 10 ~/.scripts/conkyBanshee.py --artist}${color}\n", song)
			arq.write("${color2}${alignr}${execpi 10 ~/.scripts/conkyBanshee.py --album}${color}\n")
			arq.write("${color2}${alignr}${execpi 10 ~/.scripts/conkyBanshee.py --name}${color}\n")

		#Weather Monitor
		if weather == True:
			arq.write("%s $stippled_hr\n", Weather)
			arq.write("${if_existing /proc/net/route wlan%d}\n", wlan)
			arq.write("${execpi 10800 conkyForecast --location=%s -t ~/.scripts/conkyForecast.template}\n", weather_code)
			arq.write("${else}${if_existing /proc/net/route eth%d}\n", eth)
			arq.write("${execpi 10800 conkyForecast --location=%s -t ~/.scripts/conkyForecast.template}\n", weather_code)
			arq.write("${endif}${else}${if_existing /proc/net/route ppp%d}\n", ppp)
			arq.write("${execpi 10800 conkyForecast --location=%s -t ~/.scripts/conkyForecast.template}\n", weather_code)
			arq.write("${endif}${else}")
			arq.write("${voffset 4}${color0}${font PizzaDude Bullets:size=12}4${font}${color}   %s${endif}\n",noweather)

		if (shiki==True or shikidust==True or dust ==True) and clock == ("analog" or "slim"):
			arq.write("${voffset -75}\n")

		arq.close ()


def main():

	if (len(sys.argv) == 1):
		print "Nenhum argumento foi passado!"
		sys.exit()
	else:
		parser = CommandLineParser()
		(options, args) = parser.parse_args()
		if options.version == True:
			print >> sys.stdout,"CONKY-colors v.3.91"
		languages(options.lang)
		themes(options.theme, options.alldark, options.alllight)
		conkyForecast(options.unit, options.weatherplus)
		conkyrc()

if __name__ == '__main__':
    main()
    sys.exit()
